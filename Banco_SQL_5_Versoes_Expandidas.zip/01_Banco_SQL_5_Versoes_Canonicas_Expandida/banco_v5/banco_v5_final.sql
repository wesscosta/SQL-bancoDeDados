-- Banco de Dados & SQL | banco_v5 FINAL: v4 + performance (independente da v2)
-- Compatível com MySQL 8.0.16+ / MySQL 8.4, InnoDB.
-- Fonte: conjunto canônico independente banco_v5; preserva as versões anteriores.
-- Execução única: falha se banco_v5 já existir. Não apaga outras bases.
-- Não renomeia pedidos nem utiliza pedidos_legacy.
-- Histórico v2: preserva registros, vendedores/status/pagamento desconhecidos;
-- 00:00:00 em Data_Pedido do legado marca hora não informada, não hora real da venda.
SET NAMES utf8mb4;
CREATE DATABASE `banco_v5` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `banco_v5`;

-- categorias
CREATE TABLE `categorias` (
  `ID_Categoria` INT NOT NULL,
  `Categoria` VARCHAR(80) NOT NULL,
  PRIMARY KEY (`ID_Categoria`),
  UNIQUE KEY `uk_categorias_nome` (`Categoria`)
) ENGINE=InnoDB;

INSERT INTO `categorias` VALUES
(1, 'Monitor'),
(2, 'Kit Teclado e Mouse'),
(3, 'Cadeira Gamer'),
(4, 'Headphone'),
(5, 'Microfone'),
(6, 'Notebook'),
(7, 'Acessórios');

-- locais
CREATE TABLE `locais` (
  `ID_Local` INT NOT NULL,
  `Cidade` VARCHAR(80) NOT NULL,
  `Estado` CHAR(2) NOT NULL,
  `Regiao` VARCHAR(30) NOT NULL,
  PRIMARY KEY (`ID_Local`),
  UNIQUE KEY `uk_locais_cidade_estado` (`Cidade`,`Estado`)
) ENGINE=InnoDB;

INSERT INTO `locais` VALUES
(1, 'Rio de Janeiro', 'RJ', 'Sudeste'),
(2, 'Belo Horizonte', 'MG', 'Sudeste'),
(3, 'Salvador', 'BA', 'Nordeste'),
(4, 'Curitiba', 'PR', 'Sul'),
(5, 'Fortaleza', 'CE', 'Nordeste'),
(6, 'São Paulo', 'SP', 'Sudeste'),
(7, 'Niterói', 'RJ', 'Sudeste'),
(8, 'Goiânia', 'GO', 'Centro-Oeste');

-- clientes
CREATE TABLE `clientes` (
  `ID_Cliente` INT NOT NULL,
  `Nome` VARCHAR(80) NOT NULL,
  `Sobrenome` VARCHAR(100) NOT NULL,
  `Data_Nascimento` DATE,
  `Estado_Civil` CHAR(1),
  `Sexo` CHAR(1),
  `Email` VARCHAR(150),
  `Telefone` VARCHAR(20),
  `Renda_Anual` DECIMAL(12,2),
  `Qtd_Filhos` INT DEFAULT 0,
  `Escolaridade` VARCHAR(60),
  PRIMARY KEY (`ID_Cliente`),
  UNIQUE KEY `uk_clientes_email` (`Email`),
  CHECK (`Qtd_Filhos` IS NULL OR `Qtd_Filhos` >= 0),
  CHECK (`Renda_Anual` IS NULL OR `Renda_Anual` >= 0)
) ENGINE=InnoDB;

INSERT INTO `clientes` VALUES
(1, 'Ruben', 'Torres', '1985-08-07', 'C', 'M', 'ruben35@hotmail.com', '(85) 94132-1176', 60000, 3, 'Pós-graduado'),
(2, 'Christy', 'Zhu', '1988-02-10', 'S', 'F', 'christy12@hotmail.com', '(41) 96270-6086', 70000, 0, 'Pós-graduado'),
(3, 'Elizabeth', 'Johnson', '1988-08-03', 'S', 'F', 'elizabeth5@gmail.com', '(31) 92039-5832', 80000, 5, 'Pós-graduado'),
(4, 'Julio', 'Ruiz', '1985-07-31', 'S', 'M', 'julio1@hotmail.com', '(62) 93391-5891', 70000, 0, 'Pós-graduado'),
(5, 'Janet', 'Alvarez', '1985-12-01', 'S', 'F', 'janet9@gmail.com', '(21) 93379-3743', 70000, 0, 'Pós-graduado'),
(6, 'Marco', 'Mehta', '1984-05-04', 'C', 'M', 'marco14@outlook.com', '(85) 99019-3803', 60000, 3, 'Pós-graduado'),
(7, 'Rob', 'Verhoff', '1984-07-02', 'S', 'F', 'rob4@hotmail.com', '(11) 98162-4760', 60000, 4, 'Pós-graduado'),
(8, 'Shannon', 'Carlson', '1984-03-27', 'S', 'M', 'shannon38@gmail.com', '(85) 96795-9950', 70000, 0, 'Pós-graduado'),
(9, 'Jacquelyn', 'Suarez', '1984-02-01', 'S', 'F', 'jacquelyn20@hotmail.com', '(31) 98159-7254', 70000, 0, 'Pós-graduado'),
(10, 'Curtis', 'Lu', '1983-10-30', 'C', 'M', 'curtis9@outlook.com', '(71) 94509-1440', 60000, 4, 'Pós-graduado'),
(11, 'Lauren', 'Walker', '1988-01-13', 'C', 'F', 'lauren41@hotmail.com', '(21) 93994-2382', 100000, 2, 'Pós-graduado'),
(12, 'Ian', 'Jenkins', '1988-08-01', 'C', 'M', 'ian47@gmail.com', '(21) 95385-3393', 100000, 2, 'Pós-graduado'),
(13, 'Sydney', 'Bennett', '1988-05-04', 'S', 'F', 'sydney23@gmail.com', '(11) 92024-9186', 100000, 3, 'Pós-graduado'),
(14, 'Chloe', 'Young', '1999-02-22', 'S', 'F', 'chloe23@hotmail.com', '(71) 96890-7150', 30000, 0, 'Parcial'),
(15, 'Wyatt', 'Hill', '1999-04-23', 'C', 'M', 'wyatt32@gmail.com', '(71) 98644-2695', 30000, 0, 'Parcial'),
(16, 'Shannon', 'Wang', '1964-06-21', 'S', 'F', 'shannon1@hotmail.com', '(71) 94496-1712', 20000, 4, 'Ensino médio'),
(17, 'Clarence', 'Rai', '1964-10-04', 'S', 'M', 'clarence32@outlook.com', '(21) 98923-7805', 30000, 2, 'Parcial'),
(18, 'Jordan', 'King', '1998-09-15', 'S', 'M', 'jordan73@gmail.com', '(31) 99592-6279', 40000, 0, 'Ensino médio'),
(19, 'Destiny', 'Wilson', '1998-08-29', 'S', 'F', 'destiny7@hotmail.com', '(21) 99431-6061', 40000, 0, 'Parcial'),
(20, 'Ethan', 'Zhang', '1998-10-07', 'C', 'M', 'ethan20@hotmail.com', '(11) 96440-6637', 40000, 0, 'Parcial'),
(21, 'Seth', 'Edwards', '1998-10-06', 'C', 'M', 'seth46@gmail.com', '(41) 97012-3526', 40000, 0, 'Parcial'),
(22, 'Russell', 'Xie', '1998-09-12', 'C', 'M', 'russell7@hotmail.com', NULL, 60000, 0, 'Parcial'),
(23, 'Alejandro', 'Beck', '1965-12-18', 'C', 'M', 'alejandro45@gmail.com', '(85) 94492-9582', 10000, 2, 'Parcial'),
(24, 'Harold', 'Sai', '1966-03-29', 'S', 'M', 'harold3@hotmail.com', '(31) 95052-6286', 30000, 2, 'Parcial'),
(25, 'Jessie', 'Zhao', '1966-12-02', 'C', 'M', 'jessie16@hotmail.com', '(41) 98751-8234', 30000, 2, 'Parcial'),
(26, 'Jill', 'Jimenez', '1966-04-06', 'C', 'F', 'jill13@gmail.com', '(41) 97120-5603', 30000, 2, 'Parcial'),
(27, 'Jimmy', 'Moreno', '1966-12-16', 'C', 'M', 'jimmy9@outlook.com', '(85) 92931-9277', 30000, 2, 'Parcial'),
(28, 'Bethany', 'Yuan', '1967-02-17', 'C', 'F', 'bethany10@hotmail.com', '(62) 92998-6359', 10000, 2, 'Parcial'),
(29, 'Theresa', 'Ramos', '1967-08-17', 'C', 'F', 'theresa13@hotmail.com', '(71) 92187-3667', 20000, 4, 'Ensino médio'),
(30, 'Denise', 'Stone', '1967-06-06', 'C', 'F', 'denise10@hotmail.com', '(62) 94170-5754', 20000, 4, 'Ensino médio'),
(31, 'Jaime', 'Nath', '1967-09-18', 'C', 'M', 'jaime41@outlook.com', '(21) 96759-5499', 20000, 4, 'Ensino médio'),
(32, 'Ebony', 'Gonzalez', '1967-06-14', 'C', 'F', 'ebony19@gmail.com', '(71) 99664-2156', 20000, 4, 'Ensino médio'),
(33, 'Wendy', 'Dominguez', '1968-02-19', 'C', 'F', 'wendy12@gmail.com', '(31) 97278-7135', 10000, 2, 'Parcial'),
(34, 'Jennifer', 'Russell', '1998-12-13', 'C', 'F', 'jennifer93@hotmail.com', '(21) 96714-5068', 60000, 0, 'Parcial'),
(35, 'Chloe', 'Garcia', '1997-11-22', 'S', 'F', 'chloe27@gmail.com', '(21) 94134-4552', 40000, 0, 'Parcial'),
(36, 'Diana', 'Hernandez', '1968-03-18', 'C', 'F', 'diana2@gmail.com', '(85) 93094-3166', 10000, 2, 'Parcial'),
(37, 'Marc', 'Martin', '1968-12-12', 'C', 'M', 'marc3@outlook.com', '(11) 92792-7732', 30000, 3, 'Parcial'),
(38, 'Jesse', 'Murphy', '1997-07-27', 'C', 'M', 'jesse15@outlook.com', '(62) 99674-9226', 30000, 0, 'Parcial'),
(39, 'Amanda', 'Carter', '1997-10-11', 'C', 'F', 'amanda53@gmail.com', '(71) 98283-7962', 60000, 0, 'Parcial'),
(40, 'Megan', 'Sanchez', '1997-06-08', 'C', 'F', 'megan28@hotmail.com', NULL, 70000, 0, 'Parcial'),
(41, 'Nathan', 'Simmons', '1996-02-19', 'C', 'M', 'nathan11@hotmail.com', '(11) 92589-9135', 60000, 0, 'Parcial'),
(42, 'Adam', 'Flores', '1969-05-19', 'C', 'M', 'adam10@gmail.com', '(31) 95449-1170', 20000, 2, 'Parcial'),
(43, 'Leonard', 'Nara', '1970-05-14', 'S', 'M', 'leonard18@outlook.com', '(31) 93245-4616', 30000, 3, 'Ensino médio'),
(44, 'Christine', 'Yuan', '1970-03-17', 'C', 'F', 'christine4@hotmail.com', '(31) 95294-4775', 30000, 3, 'Ensino médio'),
(45, 'Jaclyn', 'Lu', '1970-02-22', 'C', 'F', 'jaclyn12@outlook.com', '(21) 95966-1607', 30000, 3, 'Ensino médio'),
(46, 'Jeremy', 'Powell', '1970-11-17', 'C', 'M', 'jeremy26@outlook.com', '(11) 96739-1309', 30000, 3, 'Ensino médio'),
(47, 'Carol', 'Rai', '2000-07-13', 'S', 'F', 'carol8@outlook.com', '(11) 94585-9364', 40000, 0, 'Parcial'),
(48, 'Alan', 'Zheng', '1971-09-02', 'C', 'M', 'alan23@hotmail.com', '(62) 96866-5250', 30000, 3, 'Ensino médio'),
(49, 'Daniel', 'Johnson', '1971-07-30', 'S', 'M', 'daniel18@gmail.com', '(31) 98422-3549', 30000, 3, 'Ensino médio'),
(50, 'Heidi', 'Lopez', '1971-08-02', 'S', 'F', 'heidi19@outlook.com', '(11) 92303-4933', 40000, 2, 'Parcial'),
(51, 'Ana', 'Price', '2000-08-15', 'C', 'F', 'ana0@outlook.com', '(21) 99193-2686', 60000, 0, 'Parcial'),
(52, 'Deanna', 'Munoz', '1972-03-05', 'C', 'F', 'deanna33@outlook.com', '(85) 92440-1858', 40000, 2, 'Parcial'),
(53, 'Gilbert', 'Raje', '1972-02-29', 'C', 'M', 'gilbert35@outlook.com', '(41) 95730-5711', 40000, 2, 'Parcial'),
(54, 'Michele', 'Nath', '1973-03-29', 'C', 'F', 'michele19@outlook.com', '(62) 98188-6208', 40000, 3, 'Parcial'),
(55, 'Carl', 'Andersen', '1973-10-07', 'C', 'M', 'carl12@gmail.com', '(11) 97180-1463', 70000, 2, 'Graduação'),
(56, 'Marc', 'Diaz', '1974-04-22', 'C', 'M', 'marc6@gmail.com', '(41) 92126-6598', 80000, 2, 'Parcial'),
(57, 'Ashlee', 'Andersen', '1974-03-27', 'S', 'F', 'ashlee19@gmail.com', '(85) 97355-1991', 80000, 2, 'Parcial'),
(58, 'Jon', 'Zhou', '1974-03-12', 'C', 'M', 'jon28@hotmail.com', '(85) 96675-4865', 80000, 2, 'Parcial'),
(59, 'Todd', 'Gao', '1974-02-22', 'C', 'M', 'todd14@gmail.com', '(11) 96585-5605', 80000, 2, 'Parcial'),
(60, 'Noah', 'Powell', '1995-08-28', 'C', 'M', 'noah5@outlook.com', '(85) 98162-6253', 40000, 0, 'Ensino médio'),
(61, 'Angela', 'Murphy', '1995-04-02', 'S', 'F', 'angela41@outlook.com', NULL, 40000, 0, 'Ensino médio'),
(62, 'Chase', 'Reed', '1995-12-02', 'C', 'M', 'chase21@hotmail.com', '', 40000, 0, 'Ensino médio'),
(63, 'Jessica', 'Henderson', '1993-10-04', 'C', 'F', 'jessica29@gmail.com', '(21) 93673-6903', 60000, 0, 'Parcial'),
(64, 'Grace', 'Butler', '1993-11-22', 'C', 'F', 'grace62@gmail.com', NULL, 70000, 0, 'Parcial'),
(65, 'Caleb', 'Carter', '1996-09-20', 'S', 'M', 'caleb40@gmail.com', '(31) 97809-1800', 60000, 0, 'Parcial'),
(66, 'Tiffany', 'Liang', '1975-09-18', 'S', 'F', 'tiffany17@gmail.com', '(21) 97231-3503', 80000, 2, 'Ensino médio'),
(67, 'Carolyn', 'Navarro', '1975-09-16', 'S', 'F', 'carolyn30@outlook.com', '(21) 94139-6777', 80000, 2, 'Ensino médio'),
(68, 'Willie', 'Raji', '1975-03-31', 'C', 'M', 'willie40@outlook.com', '(71) 97614-1995', 80000, 2, 'Ensino médio'),
(69, 'Linda', 'Serrano', '1975-06-21', 'S', 'F', 'linda31@hotmail.com', '(21) 92428-2938', 80000, 2, 'Ensino médio'),
(70, 'Casey', 'Luo', '1975-02-01', 'S', 'F', 'casey6@outlook.com', '(31) 96609-9916', 80000, 2, 'Ensino médio'),
(71, 'Amy', 'Ye', '1976-08-09', 'S', 'F', 'amy16@hotmail.com', '(41) 92958-3807', 70000, 2, 'Ensino médio'),
(72, 'Levi', 'Arun', '1976-08-23', 'S', 'M', 'levi6@gmail.com', '(71) 92754-9983', 70000, 2, 'Ensino médio'),
(73, 'Felicia', 'Jimenez', '1977-11-11', 'S', 'F', 'felicia4@gmail.com', '(85) 95647-1806', 80000, 2, 'Ensino médio'),
(74, 'Blake', 'Anderson', '1977-07-08', 'S', 'M', 'blake9@gmail.com', '(11) 98232-2736', 80000, 2, 'Ensino médio'),
(75, 'Leah', 'Ye', '1977-09-14', 'S', 'F', 'leah7@hotmail.com', '(31) 95663-3082', 80000, 2, 'Ensino médio'),
(76, 'Gina', 'Martin', '1994-01-05', 'S', 'F', 'gina1@outlook.com', '(21) 96190-3171', 40000, 0, 'Ensino médio'),
(77, 'Donald', 'Gonzalez', '1979-03-06', 'S', 'M', 'donald20@gmail.com', '(31) 96897-9735', 160000, 0, 'Graduação'),
(78, 'Damien', 'Chander', '1979-07-12', 'C', 'M', 'damien32@gmail.com', '(11) 97494-2293', 170000, 0, 'Graduação'),
(79, 'Savannah', 'Baker', '1986-07-19', 'C', 'F', 'savannah39@gmail.com', '(11) 98574-8482', 120000, 2, 'Pós-graduado'),
(80, 'Angela', 'Butler', '1986-07-30', 'S', 'F', 'angela17@gmail.com', '(31) 99100-6309', 130000, 0, 'Graduação'),
(81, 'Alyssa', 'Cox', '1986-03-10', 'C', 'F', 'alyssa37@gmail.com', '(11) 94546-6962', 130000, 0, 'Graduação'),
(82, 'Lucas', 'Phillips', '1977-09-07', 'S', 'M', 'lucas7@outlook.com', '(62) 94668-3507', 80000, 2, 'Parcial'),
(83, 'Emily', 'Johnson', '1977-07-14', 'S', 'F', 'emily1@gmail.com', '(11) 98332-4796', 60000, 2, 'Ensino médio'),
(84, 'Ryan', 'Brown', '1977-12-18', 'C', 'M', 'ryan43@gmail.com', '(85) 92637-3025', 70000, 2, 'Parcial'),
(85, 'Tamara', 'Liang', '1977-09-28', 'C', 'F', 'tamara6@gmail.com', '(62) 92170-6794', 70000, 3, 'Parcial'),
(86, 'Hunter', 'Davis', '1977-11-20', 'C', 'M', 'hunter64@gmail.com', '(85) 99032-4591', 80000, 2, 'Pós-graduado'),
(87, 'Abigail', 'Price', '1977-01-31', 'S', 'F', 'abigail25@outlook.com', '(62) 98956-4719', 80000, 2, 'Pós-graduado'),
(88, 'Trevor', 'Bryant', '1977-12-12', 'S', 'M', 'trevor18@gmail.com', NULL, 90000, 2, 'Parcial'),
(89, 'Dalton', 'Perez', '1977-03-30', 'C', 'M', 'dalton37@outlook.com', '(21) 98302-8969', 90000, 2, 'Parcial'),
(90, 'Cheryl', 'Diaz', '1987-05-01', 'C', 'F', 'cheryl4@gmail.com', '(71) 93757-3370', 90000, 2, 'Pós-graduado'),
(91, 'Aimee', 'He', '1987-09-05', 'C', 'F', 'aimee13@gmail.com', '(71) 94329-9879', 100000, 0, 'Graduação'),
(92, 'Cedric', 'Ma', '1982-03-27', 'S', 'M', 'cedric15@outlook.com', '(31) 95423-4764', 70000, 1, 'Parcial'),
(93, 'Chad', 'Kumar', '1982-08-27', 'S', 'M', 'chad9@gmail.com', '(21) 98828-7409', 70000, 1, 'Parcial'),
(94, 'Andrés', 'Anand', '1982-08-05', 'C', 'M', 'andrés18@gmail.com', '(41) 92114-3295', 60000, 1, 'Pós-graduado'),
(95, 'Edwin', 'Nara', '1981-10-22', 'C', 'M', 'edwin39@outlook.com', '(71) 97194-6478', 60000, 1, 'Parcial'),
(96, 'Mallory', 'Rubio', '1981-04-26', 'S', 'F', 'mallory7@hotmail.com', '(62) 93152-6617', 60000, 1, 'Parcial'),
(97, 'Adam', 'Ross', '1981-03-03', 'C', 'M', 'adam2@hotmail.com', '(31) 96502-3482', 60000, 1, 'Pós-graduado'),
(98, 'Latasha', 'Navarro', '1980-09-10', 'S', 'F', 'latasha10@outlook.com', NULL, 60000, 1, 'Parcial'),
(99, 'Abby', 'Sai', '1985-05-03', 'S', 'F', 'abby4@hotmail.com', '(85) 98841-5381', 70000, 0, 'Pós-graduado'),
(100, 'Julia', 'Nelson', '1985-04-16', 'S', 'F', 'julia7@outlook.com', '(41) 96066-9929', 80000, 5, 'Pós-graduado');

-- lojas
CREATE TABLE `lojas` (
  `ID_Loja` INT NOT NULL,
  `Loja` VARCHAR(80) NOT NULL,
  `Gerente` VARCHAR(120),
  `Endereco` VARCHAR(255),
  `Num_Funcionarios` INT,
  `Telefone` VARCHAR(20),
  `ID_Local` INT NOT NULL,
  PRIMARY KEY (`ID_Loja`),
  CONSTRAINT `fk_lojas_locais` FOREIGN KEY (`ID_Local`) REFERENCES `locais` (`ID_Local`),
  CHECK (`Num_Funcionarios` IS NULL OR `Num_Funcionarios` >= 0)
) ENGINE=InnoDB;

INSERT INTO `lojas` VALUES
(1, 'Rio de Janeiro', 'Pedro Martins', 'R. Visc. de Pirajá, 136 - Ipanema, Rio de Janeiro - RJ, 22410-000', 23, '(21) 3198-1239', 1),
(2, 'Belo Horizonte', 'Julia Freitas', 'Av. Barão Homem de Melo, 1389 - Nova Granada, Belo Horizonte - MG, 30431-425', 13, '(31) 2891-2394', 2),
(3, 'Salvador', 'Marcelo Castro', 'Shopping Barra - Av. Centenário, 2992 - Barra, Salvador - BA, 40155-150', 19, '(71) 3465-8748', 3),
(4, 'Curitiba', 'Amanda Lima', 'R. Brasílio Itiberê, 3279 - Água Verde, Curitiba - PR, 80250-160', 31, '(41) 2923-2137', 4),
(5, 'Fortaleza', 'Letícia Gomes', 'Av. Dom Luís, 500 - Aldeota, Fortaleza - CE, 60160-230', 12, '(85) 3294-1481', 5),
(6, 'São Paulo', 'Rogério Lopes', 'R. Teodoro Sampaio, 954 - Pinheiros, São Paulo - SP, 05406-050', 33, '(11) 3295-3945', 6),
(7, 'Niterói', 'Matheus Leal', 'Rua Quinze de Novembro, 8 - Loja 301a Loja 301b - Centro, Niterói - RJ, 24020-125', 18, '(21) 3134-7263', 7),
(8, 'Goiânia', 'Carlos Henrique', 'Av. Goiás Norte, 3.592 - quadra 2.1 - St. Mal. Rondon, Goiânia - GO, 74063-010', 11, NULL, 8);

-- produtos
CREATE TABLE `produtos` (
  `ID_Produto` INT NOT NULL,
  `Nome_Produto` VARCHAR(180) NOT NULL,
  `ID_Categoria` INT NOT NULL,
  `Marca_Produto` VARCHAR(80),
  `Num_Serie` VARCHAR(40),
  `Preco_Unit` DECIMAL(10,2) NOT NULL,
  `Custo_Unit` DECIMAL(10,2),
  PRIMARY KEY (`ID_Produto`),
  UNIQUE KEY `uk_produtos_num_serie` (`Num_Serie`),
  CONSTRAINT `fk_produtos_categorias` FOREIGN KEY (`ID_Categoria`) REFERENCES `categorias` (`ID_Categoria`),
  CHECK (`Preco_Unit` >= 0),
  CHECK (`Custo_Unit` IS NULL OR `Custo_Unit` >= 0)
) ENGINE=InnoDB;

INSERT INTO `produtos` VALUES
(1, 'Monitor LED 19,5\'\' Full HD HDMI', 1, 'DELL', 'MNT-DL-831923', 2300, 966),
(2, 'Monitor Curvo 24\'\' 144Hz HDMI', 1, 'SAMSUNG', 'MNT-SS-001939', 2800, 980),
(3, 'Webcam Full HD 1080p', 1, 'LOGITECH', 'WBC-LT-934GG4', 450, 90),
(4, 'Kit Teclado + Mouse sem fio Wireless', 2, 'DELL', 'KTM-DL-041039', 350, 129.5),
(5, 'Kit Teclado + Mouse Slim Bluetooth', 2, 'DELL', 'KTM-DL-111924', 280, 109.2),
(6, 'Cadeira Gamer reclinável Azul/Laranja', 3, 'ALTURA', 'CGM-AL-9N914J', 1800, 540),
(7, 'Cadeira Gamer PC Racer Vermelha', 3, 'ALTURA', 'CGM-AL-0147FI', 3100, 1395),
(8, 'Headphone Bluetooth 2000', 4, 'SONY', 'HDP-SN-194821', 600, 258),
(9, 'Fone de Ouvido Tune T5000', 4, 'JBL', 'HDP-JB-091934', 780, 327.6),
(10, 'Microfone Condensador MC1000', 5, 'AKG', 'MIC-AK-237591', 1100, 275),
(11, 'Microfone Condensador com Tripé', 5, 'BLUE', 'MIC-BL-819455', 800, 344),
(12, 'Microfone de mesa com fio condensador', 5, 'BLUE', 'MIC-BL-761411', 650, 214.5),
(13, 'Notebook LC2100 Intel Core i5 8GB', 6, 'SAMSUNG', 'NOT-SS-918457', 3400, 850),
(14, 'Notebook Inspiron 15 5000 4GB', 6, 'DELL', 'NOT-DL-000012', 3100, 1209),
(15, 'Notebook IdeaPad RF32000', 6, 'DELL', 'NOT-DL-77164I', 4200, 1176),
(16, 'Notebook Motion Ultra 2', 6, 'SAMSUNG', 'NOT-SS-13139U', 2900, 1160);

-- vendedores
CREATE TABLE `vendedores` (
  `ID_Vendedor` INT NOT NULL AUTO_INCREMENT,
  `Nome` VARCHAR(100) NOT NULL,
  `Email` VARCHAR(150),
  `Data_Nascimento` DATE,
  `ID_Loja` INT NOT NULL,
  PRIMARY KEY (`ID_Vendedor`),
  UNIQUE KEY `uk_vendedores_email` (`Email`),
  CONSTRAINT `fk_vendedores_lojas` FOREIGN KEY (`ID_Loja`) REFERENCES `lojas` (`ID_Loja`)
) ENGINE=InnoDB;

INSERT INTO `vendedores` VALUES
(1, 'Maria Oliveira', 'maria@email.com', '1992-03-15', 1),
(2, 'Jose da Silva', 'Jose@email.com', '1994-02-25', 2),
(4, 'Antonio Costa', 'Antonio@email.com', '1990-12-01', 2),
(5, 'Fulano de Tal', 'fulano@email.com', '1998-05-15', 3),
(6, 'Marta da Silva', 'Marta@email.com', '1996-10-11', 4),
(7, 'Bruna Azevedo', 'bruna.azevedo@exemplo.com', '1992-01-15', 1),
(8, 'Rogério Nunes', 'rogerio.nunes@exemplo.com', '1987-07-11', 1),
(9, 'Camila Duarte', 'camila.duarte@exemplo.com', '1994-05-18', 2),
(10, 'Eduardo Silveira', 'eduardo.silveira@exemplo.com', '1989-12-30', 2),
(11, 'Patrícia Andrade', 'patricia.andrade@exemplo.com', '1993-08-21', 3),
(12, 'Carlos Mendes', 'carlos.mendes@exemplo.com', '1985-09-10', 3),
(13, 'Mariana Lopes', 'mariana.lopes@exemplo.com', '1991-04-03', 4),
(14, 'Felipe Carvalho', 'felipe.carvalho@exemplo.com', '1990-06-14', 4),
(15, 'Tatiane Fernandes', 'tatiane.fernandes@exemplo.com', '1995-02-27', 5),
(16, 'Henrique Souza', 'henrique.souza@exemplo.com', '1986-03-12', 5),
(17, 'Juliana Pinto', 'juliana.pinto@exemplo.com', '1994-11-22', 6),
(18, 'Bruno Reis', 'bruno.reis@exemplo.com', '1988-10-01', 6),
(19, 'Larissa Nogueira', 'larissa.nogueira@exemplo.com', '1992-09-17', 7),
(20, 'Marcelo Rocha', 'marcelo.rocha@exemplo.com', '1990-05-06', 7),
(21, 'Jéssica Leite', 'jessica.leite@exemplo.com', '1991-03-25', 8),
(22, 'Leonardo Castro', 'leonardo.castro@exemplo.com', '1987-07-29', 8),
(23, 'Amanda Barros', 'amanda.barros@exemplo.com', '1996-01-09', 1),
(24, 'Vinicius Silva', 'vinicius.silva@exemplo.com', '1989-12-12', 1),
(25, 'Cláudia Ribeiro', 'claudia.ribeiro@exemplo.com', '1993-04-02', 2),
(26, 'Tiago Fernandes', 'tiago.fernandes@exemplo.com', '1985-08-20', 2),
(27, 'Letícia Monteiro', 'leticia.monteiro@exemplo.com', '1990-10-18', 3),
(28, 'Anderson Oliveira', 'anderson.oliveira@exemplo.com', '1992-06-26', 3),
(29, 'Carolina Costa', 'carolina.costa@exemplo.com', '1988-11-13', 4),
(30, 'Renato Martins', 'renato.martins@exemplo.com', '1991-01-30', 4),
(31, 'Nathália Lima', 'nathalia.lima@exemplo.com', '1994-02-19', 5),
(32, 'João Almeida', 'joao.almeida@exemplo.com', '1986-07-07', 5),
(33, 'Vanessa Melo', 'vanessa.melo@exemplo.com', '1995-09-23', 6),
(34, 'Diego Ramos', 'diego.ramos@exemplo.com', '1993-12-17', 6),
(35, 'Bárbara Tavares', 'barbara.tavares@exemplo.com', '1992-03-11', 7),
(36, 'Lucas Lima', 'lucas.lima@exemplo.com', '1987-08-03', 7),
(37, 'Cristina Martins', 'cristina.martins@exemplo.com', '1990-05-15', 8),
(38, 'Ricardo Torres', 'ricardo.torres@exemplo.com', '1989-02-01', 8),
(39, 'Juliane Bastos', 'juliane.bastos@exemplo.com', '1996-10-29', 1),
(40, 'Alan Viana', 'alan.viana@exemplo.com', '1991-06-07', 2),
(41, 'Débora Souza', 'debora.souza@exemplo.com', '1988-09-12', 3),
(42, 'Fábio Corrêa', 'fabio.correa@exemplo.com', '1990-11-08', 4),
(43, 'Isadora Freitas', 'isadora.freitas@exemplo.com', '1995-04-28', 5),
(44, 'Marcela Duarte', 'marcela.duarte@exemplo.com', '1993-06-10', 6),
(45, 'Renan Silva', 'renan.silva@exemplo.com', '1987-12-24', 7),
(46, 'Elaine Rocha', 'elaine.rocha@exemplo.com', '1992-07-01', 8);

-- Catálogos operacionais introduzidos na v3.
CREATE TABLE status_pedido (
    ID_Status TINYINT NOT NULL,
    Descricao VARCHAR(40) NOT NULL,
    PRIMARY KEY (ID_Status),
    CONSTRAINT uk_status_pedido_descricao UNIQUE (Descricao)
) ENGINE=InnoDB;
INSERT INTO status_pedido (ID_Status,Descricao) VALUES
(1,'Pendente'),(2,'Processando'),(3,'Cancelado'),(4,'Concluído'),(5,'Histórico sem informação');

CREATE TABLE formas_pagamento (
    ID_Forma TINYINT NOT NULL,
    Descricao VARCHAR(40) NOT NULL,
    PRIMARY KEY (ID_Forma),
    CONSTRAINT uk_formas_pagamento_descricao UNIQUE (Descricao)
) ENGINE=InnoDB;
INSERT INTO formas_pagamento (ID_Forma,Descricao) VALUES
(1,'Dinheiro'),(2,'Pix'),(3,'Cartão de crédito'),(4,'Cartão de débito'),(5,'Boleto');

CREATE TABLE status_pagamento (
    ID_Status TINYINT NOT NULL,
    Descricao VARCHAR(40) NOT NULL,
    PRIMARY KEY (ID_Status),
    CONSTRAINT uk_status_pagamento_descricao UNIQUE (Descricao)
) ENGINE=InnoDB;
INSERT INTO status_pagamento (ID_Status,Descricao) VALUES
(1,'Pendente'),(2,'Aprovado'),(3,'Estornado'),(4,'Rejeitado');

-- A FK de pedidos valida também que vendedor pertence à loja correta.
ALTER TABLE vendedores
    ADD CONSTRAINT uk_vendedores_vendedor_loja UNIQUE (ID_Vendedor, ID_Loja);

-- Cabeçalho: uma linha por pedido. Não há ID_Produto neste cabeçalho.
CREATE TABLE pedidos (
    ID_Pedido INT NOT NULL,
    Data_Pedido DATETIME NOT NULL,
    ID_Loja INT NOT NULL,
    ID_Cliente INT NOT NULL,
    ID_Vendedor INT NULL,
    ID_Status TINYINT NOT NULL,
    Valor_Total DECIMAL(12,2) NOT NULL,
    Custo_Total DECIMAL(12,2) NULL,
    Origem_Registro VARCHAR(16) NOT NULL,
    Observacao VARCHAR(255) NULL,
    PRIMARY KEY (ID_Pedido),
    KEY idx_pedidos_cliente (ID_Cliente),
    KEY idx_pedidos_loja (ID_Loja),
    KEY idx_pedidos_data (Data_Pedido),
    KEY idx_pedidos_status (ID_Status),
    KEY idx_pedidos_vendedor_loja (ID_Vendedor,ID_Loja),
    CONSTRAINT ck_pedidos_valor CHECK (Valor_Total >= 0),
    CONSTRAINT ck_pedidos_custo CHECK (Custo_Total IS NULL OR Custo_Total >= 0),
    CONSTRAINT ck_pedidos_origem CHECK (
        (Origem_Registro='LEGADO_V2' AND ID_Vendedor IS NULL AND ID_Status=5) OR
        (Origem_Registro='OPERACAO_V3' AND ID_Vendedor IS NOT NULL AND ID_Status BETWEEN 1 AND 4)
    ),
    CONSTRAINT fk_pedidos_v3_clientes FOREIGN KEY (ID_Cliente) REFERENCES clientes(ID_Cliente),
    CONSTRAINT fk_pedidos_v3_lojas FOREIGN KEY (ID_Loja) REFERENCES lojas(ID_Loja),
    CONSTRAINT fk_pedidos_v3_status FOREIGN KEY (ID_Status) REFERENCES status_pedido(ID_Status),
    CONSTRAINT fk_pedidos_v3_vendedor_loja FOREIGN KEY (ID_Vendedor, ID_Loja)
        REFERENCES vendedores(ID_Vendedor, ID_Loja)
) ENGINE=InnoDB;

-- Detalhe: uma linha por produto de cada pedido.
CREATE TABLE itens_pedido (
    ID_Item INT NOT NULL AUTO_INCREMENT,
    ID_Pedido INT NOT NULL,
    ID_Produto INT NOT NULL,
    Quantidade INT NOT NULL,
    Preco_Unit DECIMAL(10,2) NOT NULL,
    Custo_Unit DECIMAL(10,2) NULL,
    Desconto_Valor DECIMAL(12,2) NOT NULL DEFAULT 0,
    Ajuste_Valor DECIMAL(12,2) NOT NULL DEFAULT 0,
    PRIMARY KEY (ID_Item),
    CONSTRAINT uk_itens_pedido_produto UNIQUE (ID_Pedido, ID_Produto),
    KEY idx_itens_pedido_produto (ID_Produto),
    CONSTRAINT ck_itens_qtd CHECK (Quantidade > 0),
    CONSTRAINT ck_itens_preco CHECK (Preco_Unit >= 0),
    CONSTRAINT ck_itens_custo CHECK (Custo_Unit IS NULL OR Custo_Unit >= 0),
    CONSTRAINT ck_itens_desconto CHECK (Desconto_Valor >= 0),
    CONSTRAINT ck_itens_subtotal CHECK (
        Quantidade * Preco_Unit - Desconto_Valor + Ajuste_Valor >= 0
    ),
    CONSTRAINT fk_itens_pedido_cabecalho FOREIGN KEY (ID_Pedido) REFERENCES pedidos(ID_Pedido),
    CONSTRAINT fk_itens_pedido_produto FOREIGN KEY (ID_Produto) REFERENCES produtos(ID_Produto)
) ENGINE=InnoDB;

CREATE TABLE pagamentos (
    ID_Pagamento INT NOT NULL AUTO_INCREMENT,
    ID_Pedido INT NOT NULL,
    ID_Forma TINYINT NOT NULL,
    ID_Status TINYINT NOT NULL,
    Valor_Pagamento DECIMAL(12,2) NOT NULL,
    Data_Pagamento DATETIME NULL,
    Observacao VARCHAR(255) NULL,
    PRIMARY KEY (ID_Pagamento),
    KEY idx_pagamentos_pedido (ID_Pedido),
    CONSTRAINT ck_pagamentos_valor CHECK (Valor_Pagamento > 0),
    CONSTRAINT ck_pagamentos_aprovado_data CHECK (ID_Status <> 2 OR Data_Pagamento IS NOT NULL),
    CONSTRAINT fk_pagamentos_pedidos FOREIGN KEY (ID_Pedido) REFERENCES pedidos(ID_Pedido),
    CONSTRAINT fk_pagamentos_formas FOREIGN KEY (ID_Forma) REFERENCES formas_pagamento(ID_Forma),
    CONSTRAINT fk_pagamentos_status FOREIGN KEY (ID_Status) REFERENCES status_pagamento(ID_Status)
) ENGINE=InnoDB;

-- 374 ocorrências históricas da v2: 374 cabeçalhos; vendedor/status/pagamento desconhecidos.
INSERT INTO pedidos (ID_Pedido,Data_Pedido,ID_Loja,ID_Cliente,ID_Vendedor,ID_Status,Valor_Total,Custo_Total,Origem_Registro,Observacao) VALUES
(1, '2019-01-01 00:00:00', 2, 16, NULL, 5, 350, 129.5, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(2, '2019-01-01 00:00:00', 1, 17, NULL, 5, 350, 129.5, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(3, '2019-01-01 00:00:00', 3, 23, NULL, 5, 350, 129.5, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(4, '2019-01-01 00:00:00', 8, 24, NULL, 5, 350, 129.5, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(5, '2019-01-01 00:00:00', 4, 25, NULL, 5, 350, 129.5, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(6, '2019-01-01 00:00:00', 4, 26, NULL, 5, 350, 129.5, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(7, '2019-01-01 00:00:00', 2, 14, NULL, 5, 1800, 540, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(8, '2019-01-01 00:00:00', 8, 15, NULL, 5, 1800, 540, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(9, '2019-01-01 00:00:00', 7, 38, NULL, 5, 1800, 540, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(10, '2019-01-02 00:00:00', 3, 27, NULL, 5, 450, 90, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(11, '2019-01-02 00:00:00', 4, 28, NULL, 5, 450, 90, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(12, '2019-01-02 00:00:00', 8, 29, NULL, 5, 450, 90, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(13, '2019-01-02 00:00:00', 2, 30, NULL, 5, 450, 90, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(14, '2019-01-02 00:00:00', 4, 31, NULL, 5, 450, 90, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(15, '2019-01-02 00:00:00', 7, 32, NULL, 5, 450, 90, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(16, '2019-01-03 00:00:00', 8, 33, NULL, 5, 350, 129.5, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(17, '2019-01-03 00:00:00', 8, 36, NULL, 5, 350, 129.5, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(18, '2019-01-03 00:00:00', 1, 37, NULL, 5, 350, 129.5, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(19, '2019-01-03 00:00:00', 6, 42, NULL, 5, 350, 129.5, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(20, '2019-01-03 00:00:00', 8, 43, NULL, 5, 350, 129.5, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(21, '2019-01-03 00:00:00', 6, 44, NULL, 5, 350, 129.5, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(22, '2019-01-04 00:00:00', 3, 45, NULL, 5, 1800, 540, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(23, '2019-01-04 00:00:00', 5, 46, NULL, 5, 1800, 540, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(24, '2019-01-04 00:00:00', 2, 48, NULL, 5, 1800, 540, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(25, '2019-01-04 00:00:00', 4, 49, NULL, 5, 1800, 540, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(26, '2019-12-26 00:00:00', 8, 29, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(27, '2019-12-27 00:00:00', 5, 70, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(28, '2019-12-27 00:00:00', 5, 95, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(29, '2019-12-27 00:00:00', 5, 9, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(30, '2019-12-27 00:00:00', 1, 66, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(31, '2019-12-27 00:00:00', 6, 91, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(32, '2019-12-28 00:00:00', 8, 13, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(33, '2019-12-29 00:00:00', 8, 51, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(34, '2019-12-29 00:00:00', 1, 17, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(35, '2019-12-29 00:00:00', 8, 33, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(36, '2019-12-30 00:00:00', 4, 8, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(37, '2019-01-01 00:00:00', 2, 26, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(38, '2019-01-01 00:00:00', 3, 9, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(39, '2019-01-01 00:00:00', 2, 19, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(40, '2019-01-01 00:00:00', 3, 50, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(41, '2019-01-01 00:00:00', 2, 61, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(42, '2019-01-01 00:00:00', 1, 72, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(43, '2019-01-01 00:00:00', 2, 88, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(44, '2019-01-01 00:00:00', 4, 99, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(45, '2019-01-01 00:00:00', 4, 20, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(46, '2019-01-01 00:00:00', 5, 60, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(47, '2019-01-01 00:00:00', 6, 86, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(48, '2019-01-01 00:00:00', 2, 21, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(49, '2019-01-01 00:00:00', 8, 61, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(50, '2019-01-01 00:00:00', 3, 87, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(51, '2019-01-01 00:00:00', 4, 19, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(52, '2019-01-01 00:00:00', 8, 51, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(53, '2019-01-01 00:00:00', 3, 85, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(54, '2019-01-01 00:00:00', 6, 10, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(55, '2019-01-01 00:00:00', 2, 20, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(56, '2019-01-01 00:00:00', 5, 31, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(57, '2019-01-01 00:00:00', 6, 42, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(58, '2019-01-01 00:00:00', 1, 53, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(59, '2019-01-01 00:00:00', 3, 64, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(60, '2019-01-01 00:00:00', 7, 75, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(61, '2019-01-01 00:00:00', 8, 86, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(62, '2019-01-01 00:00:00', 6, 97, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(63, '2019-01-01 00:00:00', 4, 9, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(64, '2019-01-01 00:00:00', 6, 19, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(65, '2019-01-01 00:00:00', 5, 30, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(66, '2019-01-01 00:00:00', 2, 41, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(67, '2019-01-01 00:00:00', 1, 52, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(68, '2019-01-01 00:00:00', 5, 63, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(69, '2019-01-01 00:00:00', 1, 74, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(70, '2019-01-01 00:00:00', 7, 85, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(71, '2019-01-01 00:00:00', 1, 96, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(72, '2019-01-01 00:00:00', 6, 1, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(73, '2019-01-01 00:00:00', 5, 12, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(74, '2019-01-01 00:00:00', 5, 35, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(75, '2019-01-01 00:00:00', 2, 55, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(76, '2019-01-01 00:00:00', 6, 66, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(77, '2019-01-01 00:00:00', 5, 85, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(78, '2019-01-02 00:00:00', 1, 28, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(79, '2019-01-02 00:00:00', 4, 60, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(80, '2019-01-02 00:00:00', 8, 60, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(81, '2019-01-02 00:00:00', 7, 86, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(82, '2019-01-02 00:00:00', 6, 11, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(83, '2019-01-02 00:00:00', 8, 21, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(84, '2019-01-02 00:00:00', 4, 32, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(85, '2019-01-02 00:00:00', 5, 65, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(86, '2019-01-02 00:00:00', 4, 83, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(87, '2019-01-02 00:00:00', 6, 94, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(88, '2019-01-03 00:00:00', 6, 29, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(89, '2019-01-03 00:00:00', 5, 46, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(90, '2019-01-03 00:00:00', 2, 86, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(91, '2019-01-03 00:00:00', 4, 12, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(92, '2019-01-03 00:00:00', 4, 82, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(93, '2019-01-03 00:00:00', 3, 41, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(94, '2019-01-04 00:00:00', 2, 34, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(95, '2019-01-04 00:00:00', 2, 64, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(96, '2019-01-04 00:00:00', 7, 51, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(97, '2019-01-04 00:00:00', 8, 85, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(98, '2019-01-05 00:00:00', 6, 18, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(99, '2019-01-05 00:00:00', 6, 51, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(100, '2019-01-05 00:00:00', 2, 85, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(101, '2019-01-05 00:00:00', 6, 22, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(102, '2019-01-06 00:00:00', 8, 62, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(103, '2019-01-06 00:00:00', 2, 88, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(104, '2019-01-09 00:00:00', 3, 26, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(105, '2019-01-09 00:00:00', 4, 43, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(106, '2019-01-17 00:00:00', 8, 15, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(107, '2019-01-18 00:00:00', 1, 25, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(108, '2019-01-18 00:00:00', 2, 42, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(109, '2019-01-18 00:00:00', 2, 81, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(110, '2019-01-22 00:00:00', 3, 28, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(111, '2019-01-22 00:00:00', 5, 45, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(112, '2019-01-24 00:00:00', 6, 80, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(113, '2019-02-03 00:00:00', 5, 78, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(114, '2019-02-04 00:00:00', 2, 28, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(115, '2019-02-04 00:00:00', 6, 45, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(116, '2019-02-05 00:00:00', 5, 42, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(117, '2019-02-10 00:00:00', 5, 1, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(118, '2019-02-10 00:00:00', 2, 52, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(119, '2019-02-10 00:00:00', 7, 69, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(120, '2019-02-10 00:00:00', 8, 94, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(121, '2019-02-16 00:00:00', 2, 24, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(122, '2019-02-16 00:00:00', 4, 37, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(123, '2019-02-21 00:00:00', 7, 16, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(124, '2019-02-21 00:00:00', 6, 32, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(125, '2019-02-24 00:00:00', 4, 81, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(126, '2019-02-25 00:00:00', 3, 81, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(127, '2019-02-27 00:00:00', 5, 52, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(128, '2019-02-28 00:00:00', 2, 67, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(129, '2019-02-28 00:00:00', 5, 92, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(130, '2019-03-04 00:00:00', 2, 20, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(131, '2019-03-04 00:00:00', 6, 61, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(132, '2019-03-04 00:00:00', 1, 1, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(133, '2019-03-05 00:00:00', 6, 55, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(134, '2019-03-05 00:00:00', 3, 72, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(135, '2019-03-05 00:00:00', 2, 97, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(136, '2019-03-06 00:00:00', 3, 85, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(137, '2019-03-09 00:00:00', 6, 34, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(138, '2019-03-09 00:00:00', 6, 64, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(139, '2019-03-10 00:00:00', 4, 27, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(140, '2019-03-10 00:00:00', 2, 44, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(141, '2019-03-10 00:00:00', 8, 3, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(142, '2019-03-10 00:00:00', 7, 54, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(143, '2019-03-10 00:00:00', 5, 71, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(144, '2019-03-11 00:00:00', 8, 17, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(145, '2019-03-11 00:00:00', 2, 33, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(146, '2019-03-12 00:00:00', 7, 31, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(147, '2019-03-12 00:00:00', 4, 49, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(148, '2019-03-15 00:00:00', 6, 25, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(149, '2019-03-15 00:00:00', 7, 42, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(150, '2019-03-16 00:00:00', 4, 4, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(151, '2019-03-16 00:00:00', 4, 55, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(152, '2019-03-16 00:00:00', 1, 72, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(153, '2019-03-16 00:00:00', 1, 95, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(154, '2019-03-17 00:00:00', 5, 46, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(155, '2019-03-27 00:00:00', 3, 77, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(156, '2019-03-28 00:00:00', 3, 15, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(157, '2019-03-29 00:00:00', 3, 16, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(158, '2019-03-30 00:00:00', 3, 80, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(159, '2019-03-31 00:00:00', 7, 32, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(160, '2019-04-07 00:00:00', 7, 77, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(161, '2019-04-08 00:00:00', 6, 30, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(162, '2019-04-08 00:00:00', 1, 48, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(163, '2019-04-14 00:00:00', 4, 14, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(164, '2019-04-16 00:00:00', 1, 26, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(165, '2019-04-18 00:00:00', 6, 37, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(166, '2019-04-24 00:00:00', 1, 77, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(167, '2019-04-27 00:00:00', 7, 7, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(168, '2019-04-28 00:00:00', 5, 53, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(169, '2019-04-28 00:00:00', 5, 70, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(170, '2019-04-28 00:00:00', 6, 95, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(171, '2019-04-28 00:00:00', 7, 8, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(172, '2019-04-28 00:00:00', 8, 50, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(173, '2019-04-28 00:00:00', 4, 68, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(174, '2019-04-29 00:00:00', 6, 29, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(175, '2019-04-29 00:00:00', 6, 41, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(176, '2019-04-29 00:00:00', 4, 61, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(177, '2019-04-29 00:00:00', 1, 87, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(178, '2019-05-02 00:00:00', 1, 28, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(179, '2019-05-02 00:00:00', 7, 77, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(180, '2019-05-03 00:00:00', 8, 48, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(181, '2019-05-05 00:00:00', 7, 74, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(182, '2019-05-05 00:00:00', 3, 99, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(183, '2019-05-08 00:00:00', 8, 6, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(184, '2019-05-08 00:00:00', 5, 57, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(185, '2019-05-08 00:00:00', 2, 74, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(186, '2019-05-09 00:00:00', 8, 95, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(187, '2019-05-11 00:00:00', 2, 9, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(188, '2019-05-11 00:00:00', 5, 66, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(189, '2019-05-11 00:00:00', 3, 91, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(190, '2019-05-12 00:00:00', 3, 51, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(191, '2019-05-12 00:00:00', 6, 78, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(192, '2019-05-14 00:00:00', 2, 65, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(193, '2019-05-15 00:00:00', 1, 22, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(194, '2019-05-15 00:00:00', 8, 63, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(195, '2019-05-15 00:00:00', 2, 89, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(196, '2019-05-15 00:00:00', 1, 30, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(197, '2019-05-16 00:00:00', 2, 49, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(198, '2019-05-18 00:00:00', 1, 14, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(199, '2019-05-27 00:00:00', 2, 20, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(200, '2019-05-27 00:00:00', 1, 61, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status');

INSERT INTO pedidos (ID_Pedido,Data_Pedido,ID_Loja,ID_Cliente,ID_Vendedor,ID_Status,Valor_Total,Custo_Total,Origem_Registro,Observacao) VALUES
(201, '2019-05-27 00:00:00', 8, 26, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(202, '2019-05-27 00:00:00', 1, 43, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(203, '2019-05-30 00:00:00', 6, 16, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(204, '2019-05-31 00:00:00', 6, 36, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(205, '2019-06-01 00:00:00', 6, 49, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(206, '2019-06-01 00:00:00', 1, 17, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(207, '2019-06-02 00:00:00', 2, 43, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(208, '2019-06-11 00:00:00', 6, 16, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(209, '2019-06-11 00:00:00', 6, 32, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(210, '2019-06-14 00:00:00', 6, 10, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(211, '2019-06-14 00:00:00', 4, 31, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(212, '2019-06-14 00:00:00', 5, 50, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(213, '2019-06-14 00:00:00', 4, 68, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(214, '2019-06-14 00:00:00', 4, 93, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(215, '2019-06-16 00:00:00', 4, 25, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(216, '2019-06-17 00:00:00', 7, 38, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(217, '2019-06-18 00:00:00', 2, 81, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(218, '2019-06-20 00:00:00', 8, 7, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(219, '2019-06-20 00:00:00', 2, 58, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(220, '2019-06-20 00:00:00', 4, 75, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(221, '2019-06-20 00:00:00', 7, 100, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(222, '2019-06-26 00:00:00', 3, 10, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(223, '2019-06-27 00:00:00', 1, 58, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(224, '2019-06-27 00:00:00', 3, 75, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(225, '2019-06-27 00:00:00', 2, 95, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(226, '2019-06-28 00:00:00', 6, 8, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(227, '2019-06-28 00:00:00', 7, 59, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(228, '2019-06-28 00:00:00', 2, 90, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(229, '2019-06-29 00:00:00', 6, 31, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(230, '2019-06-29 00:00:00', 3, 18, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(231, '2019-06-29 00:00:00', 5, 51, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(232, '2019-06-29 00:00:00', 6, 85, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(233, '2019-07-01 00:00:00', 3, 15, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(234, '2019-07-01 00:00:00', 5, 40, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(235, '2019-07-01 00:00:00', 8, 82, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(236, '2019-07-02 00:00:00', 6, 15, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(237, '2019-07-04 00:00:00', 3, 27, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(238, '2019-07-04 00:00:00', 8, 44, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(239, '2019-07-07 00:00:00', 3, 15, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(240, '2019-07-08 00:00:00', 4, 55, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(241, '2019-07-08 00:00:00', 1, 72, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(242, '2019-07-08 00:00:00', 5, 97, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(243, '2019-07-14 00:00:00', 5, 29, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(244, '2019-07-14 00:00:00', 4, 46, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(245, '2019-07-19 00:00:00', 3, 14, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(246, '2019-07-20 00:00:00', 5, 17, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(247, '2019-07-20 00:00:00', 3, 33, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(248, '2019-07-20 00:00:00', 2, 78, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(249, '2019-07-27 00:00:00', 5, 78, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(250, '2019-07-28 00:00:00', 4, 23, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(251, '2019-07-28 00:00:00', 5, 36, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(252, '2019-07-29 00:00:00', 1, 79, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(253, '2019-08-05 00:00:00', 4, 17, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(254, '2019-08-05 00:00:00', 1, 33, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(255, '2019-08-06 00:00:00', 1, 33, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(256, '2019-08-06 00:00:00', 5, 45, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(257, '2019-08-08 00:00:00', 3, 2, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(258, '2019-08-08 00:00:00', 4, 53, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(259, '2019-08-09 00:00:00', 1, 91, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(260, '2019-08-10 00:00:00', 3, 14, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(261, '2019-08-11 00:00:00', 6, 33, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(262, '2019-08-11 00:00:00', 4, 80, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(263, '2019-08-17 00:00:00', 5, 3, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(264, '2019-08-17 00:00:00', 1, 54, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(265, '2019-08-17 00:00:00', 5, 71, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(266, '2019-08-17 00:00:00', 3, 96, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(267, '2019-08-18 00:00:00', 2, 30, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(268, '2019-08-18 00:00:00', 3, 27, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(269, '2019-08-19 00:00:00', 6, 49, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(270, '2019-08-19 00:00:00', 5, 33, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(271, '2019-08-23 00:00:00', 4, 15, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(272, '2019-08-25 00:00:00', 1, 34, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(273, '2019-08-25 00:00:00', 2, 64, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(274, '2019-08-28 00:00:00', 2, 27, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(275, '2019-08-29 00:00:00', 1, 42, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(276, '2019-08-29 00:00:00', 1, 10, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(277, '2019-08-29 00:00:00', 6, 67, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(278, '2019-08-29 00:00:00', 1, 92, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(279, '2019-08-30 00:00:00', 2, 23, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(280, '2019-08-30 00:00:00', 8, 36, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(281, '2019-08-30 00:00:00', 6, 80, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(282, '2019-08-31 00:00:00', 8, 9, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(283, '2019-09-02 00:00:00', 1, 74, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(284, '2019-09-02 00:00:00', 6, 99, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(285, '2019-09-07 00:00:00', 4, 34, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(286, '2019-09-08 00:00:00', 3, 63, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(287, '2019-09-08 00:00:00', 6, 89, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(288, '2019-09-10 00:00:00', 6, 17, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(289, '2019-09-10 00:00:00', 1, 33, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(290, '2019-09-16 00:00:00', 4, 29, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(291, '2019-09-17 00:00:00', 3, 26, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(292, '2019-09-18 00:00:00', 1, 27, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(293, '2019-09-18 00:00:00', 2, 44, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(294, '2019-09-19 00:00:00', 6, 6, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(295, '2019-09-19 00:00:00', 2, 14, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(296, '2019-09-20 00:00:00', 3, 50, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(297, '2019-09-20 00:00:00', 3, 68, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(298, '2019-09-20 00:00:00', 6, 93, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(299, '2019-09-21 00:00:00', 1, 81, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(300, '2019-09-23 00:00:00', 5, 10, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(301, '2019-09-23 00:00:00', 2, 67, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(302, '2019-09-23 00:00:00', 1, 92, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(303, '2019-09-25 00:00:00', 7, 77, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(304, '2019-09-26 00:00:00', 3, 14, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(305, '2019-09-30 00:00:00', 2, 26, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(306, '2019-09-30 00:00:00', 8, 43, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(307, '2019-10-02 00:00:00', 8, 15, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(308, '2019-10-06 00:00:00', 5, 23, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(309, '2019-10-06 00:00:00', 5, 36, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(310, '2019-10-14 00:00:00', 8, 30, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(311, '2019-10-14 00:00:00', 8, 48, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(312, '2019-10-15 00:00:00', 1, 24, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(313, '2019-10-15 00:00:00', 4, 37, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(314, '2019-10-16 00:00:00', 5, 38, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(315, '2019-10-17 00:00:00', 8, 79, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(316, '2019-10-19 00:00:00', 7, 77, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(317, '2019-10-26 00:00:00', 4, 27, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(318, '2019-10-26 00:00:00', 5, 44, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(319, '2019-10-29 00:00:00', 5, 26, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(320, '2019-10-29 00:00:00', 2, 43, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(321, '2019-11-04 00:00:00', 8, 1, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(322, '2019-11-04 00:00:00', 6, 52, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(323, '2019-11-04 00:00:00', 1, 69, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(324, '2019-11-05 00:00:00', 2, 95, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(325, '2019-11-06 00:00:00', 8, 27, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(326, '2019-11-06 00:00:00', 7, 43, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(327, '2019-11-08 00:00:00', 1, 5, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(328, '2019-11-08 00:00:00', 1, 56, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(329, '2019-11-08 00:00:00', 2, 73, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(330, '2019-11-08 00:00:00', 3, 98, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(331, '2019-11-09 00:00:00', 6, 78, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(332, '2019-11-09 00:00:00', 8, 23, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(333, '2019-11-09 00:00:00', 5, 36, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(334, '2019-11-12 00:00:00', 8, 78, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(335, '2019-11-14 00:00:00', 1, 8, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(336, '2019-11-14 00:00:00', 3, 53, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(337, '2019-11-14 00:00:00', 8, 70, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(338, '2019-11-14 00:00:00', 4, 95, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(339, '2019-11-15 00:00:00', 3, 37, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(340, '2019-11-16 00:00:00', 8, 28, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(341, '2019-11-16 00:00:00', 3, 45, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(342, '2019-11-19 00:00:00', 3, 10, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(343, '2019-11-19 00:00:00', 8, 67, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(344, '2019-11-20 00:00:00', 1, 94, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(345, '2019-11-22 00:00:00', 6, 81, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(346, '2019-11-25 00:00:00', 7, 11, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(347, '2019-11-25 00:00:00', 7, 39, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(348, '2019-11-25 00:00:00', 6, 76, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(349, '2019-11-27 00:00:00', 8, 18, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(350, '2019-11-27 00:00:00', 4, 47, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(351, '2019-11-27 00:00:00', 4, 84, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(352, '2019-11-28 00:00:00', 8, 81, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(353, '2019-11-29 00:00:00', 1, 31, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(354, '2019-11-29 00:00:00', 2, 49, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(355, '2019-11-30 00:00:00', 1, 31, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(356, '2019-11-30 00:00:00', 1, 49, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(357, '2019-12-02 00:00:00', 4, 35, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(358, '2019-12-02 00:00:00', 3, 65, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(359, '2019-12-03 00:00:00', 2, 79, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(360, '2019-12-06 00:00:00', 2, 80, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(361, '2019-12-07 00:00:00', 3, 3, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(362, '2019-12-07 00:00:00', 6, 54, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(363, '2019-12-07 00:00:00', 6, 71, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(364, '2019-12-07 00:00:00', 2, 96, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(365, '2019-12-08 00:00:00', 5, 28, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(366, '2019-12-08 00:00:00', 6, 45, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(367, '2019-12-11 00:00:00', 5, 80, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(368, '2019-12-13 00:00:00', 6, 34, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(369, '2019-12-13 00:00:00', 4, 64, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(370, '2019-12-14 00:00:00', 6, 31, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(371, '2019-12-14 00:00:00', 7, 78, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(372, '2019-12-20 00:00:00', 1, 78, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(373, '2019-12-24 00:00:00', 4, 4, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status'),
(374, '2019-12-24 00:00:00', 7, 55, NULL, 5, 600, 258, 'LEGADO_V2', 'Historico_v2_sem_hora_ou_status');

-- Itens da v2: cada linha gera exatamente um item, com ajuste explícito se houver diferença de receita.
INSERT INTO itens_pedido (ID_Pedido,ID_Produto,Quantidade,Preco_Unit,Custo_Unit,Desconto_Valor,Ajuste_Valor) VALUES
(1, 4, 1, 350, 129.5, 0, 0.00),
(2, 4, 1, 350, 129.5, 0, 0.00),
(3, 4, 1, 350, 129.5, 0, 0.00),
(4, 4, 1, 350, 129.5, 0, 0.00),
(5, 4, 1, 350, 129.5, 0, 0.00),
(6, 4, 1, 350, 129.5, 0, 0.00),
(7, 6, 1, 1800, 540, 0, 0.00),
(8, 6, 1, 1800, 540, 0, 0.00),
(9, 6, 1, 1800, 540, 0, 0.00),
(10, 3, 1, 450, 90, 0, 0.00),
(11, 3, 1, 450, 90, 0, 0.00),
(12, 3, 1, 450, 90, 0, 0.00),
(13, 3, 1, 450, 90, 0, 0.00),
(14, 3, 1, 450, 90, 0, 0.00),
(15, 3, 1, 450, 90, 0, 0.00),
(16, 4, 1, 350, 129.5, 0, 0.00),
(17, 4, 1, 350, 129.5, 0, 0.00),
(18, 4, 1, 350, 129.5, 0, 0.00),
(19, 4, 1, 350, 129.5, 0, 0.00),
(20, 4, 1, 350, 129.5, 0, 0.00),
(21, 4, 1, 350, 129.5, 0, 0.00),
(22, 6, 1, 1800, 540, 0, 0.00),
(23, 6, 1, 1800, 540, 0, 0.00),
(24, 6, 1, 1800, 540, 0, 0.00),
(25, 6, 1, 1800, 540, 0, 0.00),
(26, 8, 1, 600, 258, 0, 0.00),
(27, 8, 1, 600, 258, 0, 0.00),
(28, 8, 1, 600, 258, 0, 0.00),
(29, 8, 1, 600, 258, 0, 0.00),
(30, 8, 1, 600, 258, 0, 0.00),
(31, 8, 1, 600, 258, 0, 0.00),
(32, 8, 1, 600, 258, 0, 0.00),
(33, 8, 1, 600, 258, 0, 0.00),
(34, 8, 1, 600, 258, 0, 0.00),
(35, 8, 1, 600, 258, 0, 0.00),
(36, 8, 1, 600, 258, 0, 0.00),
(37, 8, 1, 600, 258, 0, 0.00),
(38, 8, 1, 600, 258, 0, 0.00),
(39, 8, 1, 600, 258, 0, 0.00),
(40, 8, 1, 600, 258, 0, 0.00),
(41, 8, 1, 600, 258, 0, 0.00),
(42, 8, 1, 600, 258, 0, 0.00),
(43, 8, 1, 600, 258, 0, 0.00),
(44, 8, 1, 600, 258, 0, 0.00),
(45, 8, 1, 600, 258, 0, 0.00),
(46, 8, 1, 600, 258, 0, 0.00),
(47, 8, 1, 600, 258, 0, 0.00),
(48, 8, 1, 600, 258, 0, 0.00),
(49, 8, 1, 600, 258, 0, 0.00),
(50, 8, 1, 600, 258, 0, 0.00),
(51, 8, 1, 600, 258, 0, 0.00),
(52, 8, 1, 600, 258, 0, 0.00),
(53, 8, 1, 600, 258, 0, 0.00),
(54, 8, 1, 600, 258, 0, 0.00),
(55, 8, 1, 600, 258, 0, 0.00),
(56, 8, 1, 600, 258, 0, 0.00),
(57, 8, 1, 600, 258, 0, 0.00),
(58, 8, 1, 600, 258, 0, 0.00),
(59, 8, 1, 600, 258, 0, 0.00),
(60, 8, 1, 600, 258, 0, 0.00),
(61, 8, 1, 600, 258, 0, 0.00),
(62, 8, 1, 600, 258, 0, 0.00),
(63, 8, 1, 600, 258, 0, 0.00),
(64, 8, 1, 600, 258, 0, 0.00),
(65, 8, 1, 600, 258, 0, 0.00),
(66, 8, 1, 600, 258, 0, 0.00),
(67, 8, 1, 600, 258, 0, 0.00),
(68, 8, 1, 600, 258, 0, 0.00),
(69, 8, 1, 600, 258, 0, 0.00),
(70, 8, 1, 600, 258, 0, 0.00),
(71, 8, 1, 600, 258, 0, 0.00),
(72, 8, 1, 600, 258, 0, 0.00),
(73, 8, 1, 600, 258, 0, 0.00),
(74, 8, 1, 600, 258, 0, 0.00),
(75, 8, 1, 600, 258, 0, 0.00),
(76, 8, 1, 600, 258, 0, 0.00),
(77, 8, 1, 600, 258, 0, 0.00),
(78, 8, 1, 600, 258, 0, 0.00),
(79, 8, 1, 600, 258, 0, 0.00),
(80, 8, 1, 600, 258, 0, 0.00),
(81, 8, 1, 600, 258, 0, 0.00),
(82, 8, 1, 600, 258, 0, 0.00),
(83, 8, 1, 600, 258, 0, 0.00),
(84, 8, 1, 600, 258, 0, 0.00),
(85, 8, 1, 600, 258, 0, 0.00),
(86, 8, 1, 600, 258, 0, 0.00),
(87, 8, 1, 600, 258, 0, 0.00),
(88, 8, 1, 600, 258, 0, 0.00),
(89, 8, 1, 600, 258, 0, 0.00),
(90, 8, 1, 600, 258, 0, 0.00),
(91, 8, 1, 600, 258, 0, 0.00),
(92, 8, 1, 600, 258, 0, 0.00),
(93, 8, 1, 600, 258, 0, 0.00),
(94, 8, 1, 600, 258, 0, 0.00),
(95, 8, 1, 600, 258, 0, 0.00),
(96, 8, 1, 600, 258, 0, 0.00),
(97, 8, 1, 600, 258, 0, 0.00),
(98, 8, 1, 600, 258, 0, 0.00),
(99, 8, 1, 600, 258, 0, 0.00),
(100, 8, 1, 600, 258, 0, 0.00),
(101, 8, 1, 600, 258, 0, 0.00),
(102, 8, 1, 600, 258, 0, 0.00),
(103, 8, 1, 600, 258, 0, 0.00),
(104, 8, 1, 600, 258, 0, 0.00),
(105, 8, 1, 600, 258, 0, 0.00),
(106, 8, 1, 600, 258, 0, 0.00),
(107, 8, 1, 600, 258, 0, 0.00),
(108, 8, 1, 600, 258, 0, 0.00),
(109, 8, 1, 600, 258, 0, 0.00),
(110, 8, 1, 600, 258, 0, 0.00),
(111, 8, 1, 600, 258, 0, 0.00),
(112, 8, 1, 600, 258, 0, 0.00),
(113, 8, 1, 600, 258, 0, 0.00),
(114, 8, 1, 600, 258, 0, 0.00),
(115, 8, 1, 600, 258, 0, 0.00),
(116, 8, 1, 600, 258, 0, 0.00),
(117, 8, 1, 600, 258, 0, 0.00),
(118, 8, 1, 600, 258, 0, 0.00),
(119, 8, 1, 600, 258, 0, 0.00),
(120, 8, 1, 600, 258, 0, 0.00),
(121, 8, 1, 600, 258, 0, 0.00),
(122, 8, 1, 600, 258, 0, 0.00),
(123, 8, 1, 600, 258, 0, 0.00),
(124, 8, 1, 600, 258, 0, 0.00),
(125, 8, 1, 600, 258, 0, 0.00),
(126, 8, 1, 600, 258, 0, 0.00),
(127, 8, 1, 600, 258, 0, 0.00),
(128, 8, 1, 600, 258, 0, 0.00),
(129, 8, 1, 600, 258, 0, 0.00),
(130, 8, 1, 600, 258, 0, 0.00),
(131, 8, 1, 600, 258, 0, 0.00),
(132, 8, 1, 600, 258, 0, 0.00),
(133, 8, 1, 600, 258, 0, 0.00),
(134, 8, 1, 600, 258, 0, 0.00),
(135, 8, 1, 600, 258, 0, 0.00),
(136, 8, 1, 600, 258, 0, 0.00),
(137, 8, 1, 600, 258, 0, 0.00),
(138, 8, 1, 600, 258, 0, 0.00),
(139, 8, 1, 600, 258, 0, 0.00),
(140, 8, 1, 600, 258, 0, 0.00),
(141, 8, 1, 600, 258, 0, 0.00),
(142, 8, 1, 600, 258, 0, 0.00),
(143, 8, 1, 600, 258, 0, 0.00),
(144, 8, 1, 600, 258, 0, 0.00),
(145, 8, 1, 600, 258, 0, 0.00),
(146, 8, 1, 600, 258, 0, 0.00),
(147, 8, 1, 600, 258, 0, 0.00),
(148, 8, 1, 600, 258, 0, 0.00),
(149, 8, 1, 600, 258, 0, 0.00),
(150, 8, 1, 600, 258, 0, 0.00),
(151, 8, 1, 600, 258, 0, 0.00),
(152, 8, 1, 600, 258, 0, 0.00),
(153, 8, 1, 600, 258, 0, 0.00),
(154, 8, 1, 600, 258, 0, 0.00),
(155, 8, 1, 600, 258, 0, 0.00),
(156, 8, 1, 600, 258, 0, 0.00),
(157, 8, 1, 600, 258, 0, 0.00),
(158, 8, 1, 600, 258, 0, 0.00),
(159, 8, 1, 600, 258, 0, 0.00),
(160, 8, 1, 600, 258, 0, 0.00),
(161, 8, 1, 600, 258, 0, 0.00),
(162, 8, 1, 600, 258, 0, 0.00),
(163, 8, 1, 600, 258, 0, 0.00),
(164, 8, 1, 600, 258, 0, 0.00),
(165, 8, 1, 600, 258, 0, 0.00),
(166, 8, 1, 600, 258, 0, 0.00),
(167, 8, 1, 600, 258, 0, 0.00),
(168, 8, 1, 600, 258, 0, 0.00),
(169, 8, 1, 600, 258, 0, 0.00),
(170, 8, 1, 600, 258, 0, 0.00),
(171, 8, 1, 600, 258, 0, 0.00),
(172, 8, 1, 600, 258, 0, 0.00),
(173, 8, 1, 600, 258, 0, 0.00),
(174, 8, 1, 600, 258, 0, 0.00),
(175, 8, 1, 600, 258, 0, 0.00),
(176, 8, 1, 600, 258, 0, 0.00),
(177, 8, 1, 600, 258, 0, 0.00),
(178, 8, 1, 600, 258, 0, 0.00),
(179, 8, 1, 600, 258, 0, 0.00),
(180, 8, 1, 600, 258, 0, 0.00),
(181, 8, 1, 600, 258, 0, 0.00),
(182, 8, 1, 600, 258, 0, 0.00),
(183, 8, 1, 600, 258, 0, 0.00),
(184, 8, 1, 600, 258, 0, 0.00),
(185, 8, 1, 600, 258, 0, 0.00),
(186, 8, 1, 600, 258, 0, 0.00),
(187, 8, 1, 600, 258, 0, 0.00),
(188, 8, 1, 600, 258, 0, 0.00),
(189, 8, 1, 600, 258, 0, 0.00),
(190, 8, 1, 600, 258, 0, 0.00),
(191, 8, 1, 600, 258, 0, 0.00),
(192, 8, 1, 600, 258, 0, 0.00),
(193, 8, 1, 600, 258, 0, 0.00),
(194, 8, 1, 600, 258, 0, 0.00),
(195, 8, 1, 600, 258, 0, 0.00),
(196, 8, 1, 600, 258, 0, 0.00),
(197, 8, 1, 600, 258, 0, 0.00),
(198, 8, 1, 600, 258, 0, 0.00),
(199, 8, 1, 600, 258, 0, 0.00),
(200, 8, 1, 600, 258, 0, 0.00);

INSERT INTO itens_pedido (ID_Pedido,ID_Produto,Quantidade,Preco_Unit,Custo_Unit,Desconto_Valor,Ajuste_Valor) VALUES
(201, 8, 1, 600, 258, 0, 0.00),
(202, 8, 1, 600, 258, 0, 0.00),
(203, 8, 1, 600, 258, 0, 0.00),
(204, 8, 1, 600, 258, 0, 0.00),
(205, 8, 1, 600, 258, 0, 0.00),
(206, 8, 1, 600, 258, 0, 0.00),
(207, 8, 1, 600, 258, 0, 0.00),
(208, 8, 1, 600, 258, 0, 0.00),
(209, 8, 1, 600, 258, 0, 0.00),
(210, 8, 1, 600, 258, 0, 0.00),
(211, 8, 1, 600, 258, 0, 0.00),
(212, 8, 1, 600, 258, 0, 0.00),
(213, 8, 1, 600, 258, 0, 0.00),
(214, 8, 1, 600, 258, 0, 0.00),
(215, 8, 1, 600, 258, 0, 0.00),
(216, 8, 1, 600, 258, 0, 0.00),
(217, 8, 1, 600, 258, 0, 0.00),
(218, 8, 1, 600, 258, 0, 0.00),
(219, 8, 1, 600, 258, 0, 0.00),
(220, 8, 1, 600, 258, 0, 0.00),
(221, 8, 1, 600, 258, 0, 0.00),
(222, 8, 1, 600, 258, 0, 0.00),
(223, 8, 1, 600, 258, 0, 0.00),
(224, 8, 1, 600, 258, 0, 0.00),
(225, 8, 1, 600, 258, 0, 0.00),
(226, 8, 1, 600, 258, 0, 0.00),
(227, 8, 1, 600, 258, 0, 0.00),
(228, 8, 1, 600, 258, 0, 0.00),
(229, 8, 1, 600, 258, 0, 0.00),
(230, 8, 1, 600, 258, 0, 0.00),
(231, 8, 1, 600, 258, 0, 0.00),
(232, 8, 1, 600, 258, 0, 0.00),
(233, 8, 1, 600, 258, 0, 0.00),
(234, 8, 1, 600, 258, 0, 0.00),
(235, 8, 1, 600, 258, 0, 0.00),
(236, 8, 1, 600, 258, 0, 0.00),
(237, 8, 1, 600, 258, 0, 0.00),
(238, 8, 1, 600, 258, 0, 0.00),
(239, 8, 1, 600, 258, 0, 0.00),
(240, 8, 1, 600, 258, 0, 0.00),
(241, 8, 1, 600, 258, 0, 0.00),
(242, 8, 1, 600, 258, 0, 0.00),
(243, 8, 1, 600, 258, 0, 0.00),
(244, 8, 1, 600, 258, 0, 0.00),
(245, 8, 1, 600, 258, 0, 0.00),
(246, 8, 1, 600, 258, 0, 0.00),
(247, 8, 1, 600, 258, 0, 0.00),
(248, 8, 1, 600, 258, 0, 0.00),
(249, 8, 1, 600, 258, 0, 0.00),
(250, 8, 1, 600, 258, 0, 0.00),
(251, 8, 1, 600, 258, 0, 0.00),
(252, 8, 1, 600, 258, 0, 0.00),
(253, 8, 1, 600, 258, 0, 0.00),
(254, 8, 1, 600, 258, 0, 0.00),
(255, 8, 1, 600, 258, 0, 0.00),
(256, 8, 1, 600, 258, 0, 0.00),
(257, 8, 1, 600, 258, 0, 0.00),
(258, 8, 1, 600, 258, 0, 0.00),
(259, 8, 1, 600, 258, 0, 0.00),
(260, 8, 1, 600, 258, 0, 0.00),
(261, 8, 1, 600, 258, 0, 0.00),
(262, 8, 1, 600, 258, 0, 0.00),
(263, 8, 1, 600, 258, 0, 0.00),
(264, 8, 1, 600, 258, 0, 0.00),
(265, 8, 1, 600, 258, 0, 0.00),
(266, 8, 1, 600, 258, 0, 0.00),
(267, 8, 1, 600, 258, 0, 0.00),
(268, 8, 1, 600, 258, 0, 0.00),
(269, 8, 1, 600, 258, 0, 0.00),
(270, 8, 1, 600, 258, 0, 0.00),
(271, 8, 1, 600, 258, 0, 0.00),
(272, 8, 1, 600, 258, 0, 0.00),
(273, 8, 1, 600, 258, 0, 0.00),
(274, 8, 1, 600, 258, 0, 0.00),
(275, 8, 1, 600, 258, 0, 0.00),
(276, 8, 1, 600, 258, 0, 0.00),
(277, 8, 1, 600, 258, 0, 0.00),
(278, 8, 1, 600, 258, 0, 0.00),
(279, 8, 1, 600, 258, 0, 0.00),
(280, 8, 1, 600, 258, 0, 0.00),
(281, 8, 1, 600, 258, 0, 0.00),
(282, 8, 1, 600, 258, 0, 0.00),
(283, 8, 1, 600, 258, 0, 0.00),
(284, 8, 1, 600, 258, 0, 0.00),
(285, 8, 1, 600, 258, 0, 0.00),
(286, 8, 1, 600, 258, 0, 0.00),
(287, 8, 1, 600, 258, 0, 0.00),
(288, 8, 1, 600, 258, 0, 0.00),
(289, 8, 1, 600, 258, 0, 0.00),
(290, 8, 1, 600, 258, 0, 0.00),
(291, 8, 1, 600, 258, 0, 0.00),
(292, 8, 1, 600, 258, 0, 0.00),
(293, 8, 1, 600, 258, 0, 0.00),
(294, 8, 1, 600, 258, 0, 0.00),
(295, 8, 1, 600, 258, 0, 0.00),
(296, 8, 1, 600, 258, 0, 0.00),
(297, 8, 1, 600, 258, 0, 0.00),
(298, 8, 1, 600, 258, 0, 0.00),
(299, 8, 1, 600, 258, 0, 0.00),
(300, 8, 1, 600, 258, 0, 0.00),
(301, 8, 1, 600, 258, 0, 0.00),
(302, 8, 1, 600, 258, 0, 0.00),
(303, 8, 1, 600, 258, 0, 0.00),
(304, 8, 1, 600, 258, 0, 0.00),
(305, 8, 1, 600, 258, 0, 0.00),
(306, 8, 1, 600, 258, 0, 0.00),
(307, 8, 1, 600, 258, 0, 0.00),
(308, 8, 1, 600, 258, 0, 0.00),
(309, 8, 1, 600, 258, 0, 0.00),
(310, 8, 1, 600, 258, 0, 0.00),
(311, 8, 1, 600, 258, 0, 0.00),
(312, 8, 1, 600, 258, 0, 0.00),
(313, 8, 1, 600, 258, 0, 0.00),
(314, 8, 1, 600, 258, 0, 0.00),
(315, 8, 1, 600, 258, 0, 0.00),
(316, 8, 1, 600, 258, 0, 0.00),
(317, 8, 1, 600, 258, 0, 0.00),
(318, 8, 1, 600, 258, 0, 0.00),
(319, 8, 1, 600, 258, 0, 0.00),
(320, 8, 1, 600, 258, 0, 0.00),
(321, 8, 1, 600, 258, 0, 0.00),
(322, 8, 1, 600, 258, 0, 0.00),
(323, 8, 1, 600, 258, 0, 0.00),
(324, 8, 1, 600, 258, 0, 0.00),
(325, 8, 1, 600, 258, 0, 0.00),
(326, 8, 1, 600, 258, 0, 0.00),
(327, 8, 1, 600, 258, 0, 0.00),
(328, 8, 1, 600, 258, 0, 0.00),
(329, 8, 1, 600, 258, 0, 0.00),
(330, 8, 1, 600, 258, 0, 0.00),
(331, 8, 1, 600, 258, 0, 0.00),
(332, 8, 1, 600, 258, 0, 0.00),
(333, 8, 1, 600, 258, 0, 0.00),
(334, 8, 1, 600, 258, 0, 0.00),
(335, 8, 1, 600, 258, 0, 0.00),
(336, 8, 1, 600, 258, 0, 0.00),
(337, 8, 1, 600, 258, 0, 0.00),
(338, 8, 1, 600, 258, 0, 0.00),
(339, 8, 1, 600, 258, 0, 0.00),
(340, 8, 1, 600, 258, 0, 0.00),
(341, 8, 1, 600, 258, 0, 0.00),
(342, 8, 1, 600, 258, 0, 0.00),
(343, 8, 1, 600, 258, 0, 0.00),
(344, 8, 1, 600, 258, 0, 0.00),
(345, 8, 1, 600, 258, 0, 0.00),
(346, 8, 1, 600, 258, 0, 0.00),
(347, 8, 1, 600, 258, 0, 0.00),
(348, 8, 1, 600, 258, 0, 0.00),
(349, 8, 1, 600, 258, 0, 0.00),
(350, 8, 1, 600, 258, 0, 0.00),
(351, 8, 1, 600, 258, 0, 0.00),
(352, 8, 1, 600, 258, 0, 0.00),
(353, 8, 1, 600, 258, 0, 0.00),
(354, 8, 1, 600, 258, 0, 0.00),
(355, 8, 1, 600, 258, 0, 0.00),
(356, 8, 1, 600, 258, 0, 0.00),
(357, 8, 1, 600, 258, 0, 0.00),
(358, 8, 1, 600, 258, 0, 0.00),
(359, 8, 1, 600, 258, 0, 0.00),
(360, 8, 1, 600, 258, 0, 0.00),
(361, 8, 1, 600, 258, 0, 0.00),
(362, 8, 1, 600, 258, 0, 0.00),
(363, 8, 1, 600, 258, 0, 0.00),
(364, 8, 1, 600, 258, 0, 0.00),
(365, 8, 1, 600, 258, 0, 0.00),
(366, 8, 1, 600, 258, 0, 0.00),
(367, 8, 1, 600, 258, 0, 0.00),
(368, 8, 1, 600, 258, 0, 0.00),
(369, 8, 1, 600, 258, 0, 0.00),
(370, 8, 1, 600, 258, 0, 0.00),
(371, 8, 1, 600, 258, 0, 0.00),
(372, 8, 1, 600, 258, 0, 0.00),
(373, 8, 1, 600, 258, 0, 0.00),
(374, 8, 1, 600, 258, 0, 0.00);

-- 16 pedidos NOVOS e 40 itens sintéticos, claramente separados do histórico.
INSERT INTO pedidos (ID_Pedido,Data_Pedido,ID_Loja,ID_Cliente,ID_Vendedor,ID_Status,Valor_Total,Custo_Total,Origem_Registro,Observacao) VALUES
(375, '2020-01-01 10:45:00', 6, 26, 17, 4, 10000.00, 4444.00, 'OPERACAO_V3', 'Pedido multi-itens de demonstração'),
(376, '2020-01-02 10:52:00', 1, 33, 1, 4, 8790.00, 3517.30, 'OPERACAO_V3', 'Pedido multi-itens de demonstração'),
(377, '2020-01-03 10:59:00', 4, 40, 6, 4, 7700.00, 3141.00, 'OPERACAO_V3', 'Pedido multi-itens de demonstração'),
(378, '2020-01-04 10:06:00', 7, 47, 19, 2, 7130.00, 2075.00, 'OPERACAO_V3', 'Pedido multi-itens de demonstração'),
(379, '2020-01-05 10:13:00', 2, 54, 2, 4, 2510.00, 1118.00, 'OPERACAO_V3', 'Pedido multi-itens de demonstração'),
(380, '2020-01-06 10:20:00', 5, 61, 15, 4, 10250.00, 3558.50, 'OPERACAO_V3', 'Pedido multi-itens de demonstração'),
(381, '2020-01-07 10:27:00', 8, 68, 21, 4, 6440.00, 2287.60, 'OPERACAO_V3', 'Pedido multi-itens de demonstração'),
(382, '2020-01-08 10:34:00', 3, 75, 5, 4, 16290.00, 6878.00, 'OPERACAO_V3', 'Pedido multi-itens de demonstração'),
(383, '2020-01-09 10:41:00', 6, 82, 17, 4, 8630.00, 2566.50, 'OPERACAO_V3', 'Pedido multi-itens de demonstração'),
(384, '2020-01-10 10:48:00', 1, 89, 1, 4, 6020.00, 2578.50, 'OPERACAO_V3', 'Pedido multi-itens de demonstração'),
(385, '2020-01-11 10:55:00', 4, 96, 6, 2, 6180.00, 1947.60, 'OPERACAO_V3', 'Pedido multi-itens de demonstração'),
(386, '2020-01-12 10:02:00', 7, 3, 19, 4, 15400.00, 5702.00, 'OPERACAO_V3', 'Pedido multi-itens de demonstração'),
(387, '2020-01-13 10:09:00', 2, 10, 2, 4, 7150.00, 2590.00, 'OPERACAO_V3', 'Pedido multi-itens de demonstração'),
(388, '2020-01-14 10:16:00', 5, 17, 15, 4, 2710.00, 1014.60, 'OPERACAO_V3', 'Pedido multi-itens de demonstração'),
(389, '2020-01-15 10:23:00', 8, 24, 21, 4, 7845.00, 1975.00, 'OPERACAO_V3', 'Pedido multi-itens de demonstração'),
(390, '2020-01-16 10:30:00', 3, 31, 5, 4, 18600.00, 5832.00, 'OPERACAO_V3', 'Pedido multi-itens de demonstração');

INSERT INTO itens_pedido (ID_Pedido,ID_Produto,Quantidade,Preco_Unit,Custo_Unit,Desconto_Valor,Ajuste_Valor) VALUES
(375, 4, 2, 350.00, 129.50, 0.00, 0),
(375, 7, 3, 3100.00, 1395.00, 0.00, 0),
(376, 9, 3, 780.00, 327.60, 0.00, 0),
(376, 12, 1, 650.00, 214.50, 0.00, 0),
(376, 16, 2, 2900.00, 1160.00, 0.00, 0),
(377, 14, 1, 3100.00, 1209.00, 0.00, 0),
(377, 1, 2, 2300.00, 966.00, 0.00, 0),
(378, 3, 2, 450.00, 90.00, 0.00, 0),
(378, 6, 3, 1800.00, 540.00, 270.00, 0),
(378, 10, 1, 1100.00, 275.00, 0.00, 0),
(379, 8, 3, 600.00, 258.00, 90.00, 0),
(379, 11, 1, 800.00, 344.00, 0.00, 0),
(380, 13, 1, 3400.00, 850.00, 0.00, 0),
(380, 16, 2, 2900.00, 1160.00, 0.00, 0),
(380, 4, 3, 350.00, 129.50, 0.00, 0),
(381, 2, 2, 2800.00, 980.00, 0.00, 0),
(381, 5, 3, 280.00, 109.20, 0.00, 0),
(382, 7, 3, 3100.00, 1395.00, 0.00, 0),
(382, 10, 1, 1100.00, 275.00, 0.00, 0),
(382, 14, 2, 3100.00, 1209.00, 310.00, 0),
(383, 12, 1, 650.00, 214.50, 0.00, 0),
(383, 15, 2, 4200.00, 1176.00, 420.00, 0),
(384, 1, 2, 2300.00, 966.00, 230.00, 0),
(384, 4, 3, 350.00, 129.50, 0.00, 0),
(384, 8, 1, 600.00, 258.00, 0.00, 0),
(385, 6, 3, 1800.00, 540.00, 0.00, 0),
(385, 9, 1, 780.00, 327.60, 0.00, 0),
(386, 11, 1, 800.00, 344.00, 0.00, 0),
(386, 14, 2, 3100.00, 1209.00, 0.00, 0),
(386, 2, 3, 2800.00, 980.00, 0.00, 0),
(387, 16, 2, 2900.00, 1160.00, 0.00, 0),
(387, 3, 3, 450.00, 90.00, 0.00, 0),
(388, 5, 3, 280.00, 109.20, 0.00, 0),
(388, 8, 1, 600.00, 258.00, 30.00, 0),
(388, 12, 2, 650.00, 214.50, 0.00, 0),
(389, 10, 1, 1100.00, 275.00, 55.00, 0),
(389, 13, 2, 3400.00, 850.00, 0.00, 0),
(390, 15, 2, 4200.00, 1176.00, 0.00, 0),
(390, 2, 3, 2800.00, 980.00, 0.00, 0),
(390, 6, 1, 1800.00, 540.00, 0.00, 0);

-- Pagamentos apenas para os 16 pedidos sintéticos; nenhum pagamento histórico é fabricado.
INSERT INTO pagamentos (ID_Pedido,ID_Forma,ID_Status,Valor_Pagamento,Data_Pagamento,Observacao) VALUES
(375, 1, 2, 10000.00, '2020-01-01 10:45:00', 'Pagamento sintético de laboratório'),
(376, 2, 2, 8790.00, '2020-01-02 10:52:00', 'Pagamento sintético de laboratório'),
(377, 3, 2, 7700.00, '2020-01-03 10:59:00', 'Pagamento sintético de laboratório'),
(378, 4, 2, 7130.00, '2020-01-04 10:06:00', 'Pagamento sintético de laboratório'),
(379, 5, 2, 2510.00, '2020-01-05 10:13:00', 'Pagamento sintético de laboratório'),
(380, 1, 2, 10250.00, '2020-01-06 10:20:00', 'Pagamento sintético de laboratório'),
(381, 2, 2, 6440.00, '2020-01-07 10:27:00', 'Pagamento sintético de laboratório'),
(382, 3, 2, 16290.00, '2020-01-08 10:34:00', 'Pagamento sintético de laboratório'),
(383, 4, 2, 8630.00, '2020-01-09 10:41:00', 'Pagamento sintético de laboratório'),
(384, 5, 2, 6020.00, '2020-01-10 10:48:00', 'Pagamento sintético de laboratório'),
(385, 1, 2, 6180.00, '2020-01-11 10:55:00', 'Pagamento sintético de laboratório'),
(386, 2, 2, 15400.00, '2020-01-12 10:02:00', 'Pagamento sintético de laboratório'),
(387, 3, 2, 7150.00, '2020-01-13 10:09:00', 'Pagamento sintético de laboratório'),
(388, 4, 2, 2710.00, '2020-01-14 10:16:00', 'Pagamento sintético de laboratório'),
(389, 5, 2, 7845.00, '2020-01-15 10:23:00', 'Pagamento sintético de laboratório'),
(390, 1, 2, 18600.00, '2020-01-16 10:30:00', 'Pagamento sintético de laboratório');


-- Evolução v3 -> v4: suprimentos, compras, estoque e rastreabilidade.
-- Executar apenas sobre banco_v4 novo e integralmente copiado da v3.
USE banco_v5;

CREATE TABLE fornecedores (
    ID_Fornecedor INT NOT NULL AUTO_INCREMENT,
    Nome_Fornecedor VARCHAR(120) NOT NULL,
    CNPJ VARCHAR(18) NULL,
    Telefone VARCHAR(20) NULL,
    Email VARCHAR(120) NULL,
    PRIMARY KEY (ID_Fornecedor),
    UNIQUE KEY uk_fornecedores_cnpj (CNPJ),
    UNIQUE KEY uk_fornecedores_email (Email)
) ENGINE=InnoDB;

INSERT INTO fornecedores (Nome_Fornecedor,CNPJ,Telefone,Email) VALUES
('Tech Supply Brasil','10.000.001/0001-01','(11) 3000-0001','contato01@fornecedor.local'),
('Nordeste Componentes','10.000.002/0001-02','(85) 3000-0002','contato02@fornecedor.local'),
('Sul Digital','10.000.003/0001-03','(41) 3000-0003','contato03@fornecedor.local'),
('Minas Hardware','10.000.004/0001-04','(31) 3000-0004','contato04@fornecedor.local'),
('Bahia Tech','10.000.005/0001-05','(71) 3000-0005','contato05@fornecedor.local'),
('Goiás Distribuição','10.000.006/0001-06','(62) 3000-0006','contato06@fornecedor.local'),
('Rio Componentes','10.000.007/0001-07','(21) 3000-0007','contato07@fornecedor.local'),
('Paulista Devices','10.000.008/0001-08','(11) 3000-0008','contato08@fornecedor.local'),
('Conecta Informática','10.000.009/0001-09','(85) 3000-0009','contato09@fornecedor.local'),
('Prime Hardware','10.000.010/0001-10','(31) 3000-0010','contato10@fornecedor.local'),
('Global Periféricos','10.000.011/0001-11','(41) 3000-0011','contato11@fornecedor.local'),
('Data Commerce','10.000.012/0001-12','(71) 3000-0012','contato12@fornecedor.local'),
('Central Notebook','10.000.013/0001-13','(62) 3000-0013','contato13@fornecedor.local'),
('Audio Pro Supply','10.000.014/0001-14','(21) 3000-0014','contato14@fornecedor.local'),
('Office Gamer Parts','10.000.015/0001-15','(11) 3000-0015','contato15@fornecedor.local');

CREATE TABLE produto_fornecedor (
    ID_Produto INT NOT NULL,
    ID_Fornecedor INT NOT NULL,
    Preco_Compra DECIMAL(12,2) NOT NULL,
    Fornecedor_Principal BOOLEAN NOT NULL DEFAULT FALSE,
    Prazo_Dias SMALLINT NULL,
    PRIMARY KEY (ID_Produto, ID_Fornecedor),
    CONSTRAINT ck_produto_fornecedor_preco CHECK (Preco_Compra > 0),
    CONSTRAINT ck_produto_fornecedor_prazo CHECK (Prazo_Dias IS NULL OR Prazo_Dias >= 0),
    CONSTRAINT fk_produto_fornecedor_produto FOREIGN KEY (ID_Produto) REFERENCES produtos(ID_Produto),
    CONSTRAINT fk_produto_fornecedor_fornecedor FOREIGN KEY (ID_Fornecedor) REFERENCES fornecedores(ID_Fornecedor)
) ENGINE=InnoDB;

INSERT INTO produto_fornecedor (ID_Produto,ID_Fornecedor,Preco_Compra,Fornecedor_Principal,Prazo_Dias)
SELECT ID_Produto, 1+MOD(ID_Produto-1,15), ROUND(COALESCE(Custo_Unit,Preco_Unit*0.55)*0.95,2), TRUE, 5+MOD(ID_Produto,8)
FROM produtos;
INSERT INTO produto_fornecedor (ID_Produto,ID_Fornecedor,Preco_Compra,Fornecedor_Principal,Prazo_Dias)
SELECT ID_Produto, 1+MOD(ID_Produto+4,15), ROUND(COALESCE(Custo_Unit,Preco_Unit*0.55)*1.03,2), FALSE, 7+MOD(ID_Produto,10)
FROM produtos;

CREATE TABLE status_compra (
    ID_Status_Compra TINYINT NOT NULL,
    Status_Compra VARCHAR(30) NOT NULL,
    PRIMARY KEY (ID_Status_Compra),
    UNIQUE KEY uk_status_compra_nome (Status_Compra)
) ENGINE=InnoDB;
INSERT INTO status_compra VALUES (1,'Aberta'),(2,'Recebida'),(3,'Cancelada');

CREATE TABLE compras (
    ID_Compra INT NOT NULL AUTO_INCREMENT,
    Data_Compra DATETIME NOT NULL,
    ID_Fornecedor INT NOT NULL,
    ID_Loja INT NOT NULL,
    ID_Status_Compra TINYINT NOT NULL,
    Valor_Total DECIMAL(12,2) NOT NULL DEFAULT 0,
    PRIMARY KEY (ID_Compra),
    KEY idx_compras_fornecedor (ID_Fornecedor),
    KEY idx_compras_loja (ID_Loja),
    KEY idx_compras_data (Data_Compra),
    CONSTRAINT ck_compras_valor_total CHECK (Valor_Total >= 0),
    CONSTRAINT fk_compras_fornecedor FOREIGN KEY (ID_Fornecedor) REFERENCES fornecedores(ID_Fornecedor),
    CONSTRAINT fk_compras_loja FOREIGN KEY (ID_Loja) REFERENCES lojas(ID_Loja),
    UNIQUE KEY uk_compras_compra_fornecedor (ID_Compra, ID_Fornecedor),
    CONSTRAINT fk_compras_status FOREIGN KEY (ID_Status_Compra) REFERENCES status_compra(ID_Status_Compra)
) ENGINE=InnoDB;

CREATE TABLE itens_compra (
    ID_Item_Compra INT NOT NULL AUTO_INCREMENT,
    ID_Compra INT NOT NULL,
    ID_Produto INT NOT NULL,
    ID_Fornecedor INT NOT NULL,
    Quantidade INT NOT NULL,
    Custo_Unit DECIMAL(12,2) NOT NULL,
    PRIMARY KEY (ID_Item_Compra),
    UNIQUE KEY uk_itens_compra_produto (ID_Compra, ID_Produto),
    KEY idx_itens_compra_produto (ID_Produto),
    KEY idx_itens_compra_fornecedor (ID_Fornecedor),
    CONSTRAINT ck_itens_compra_qtd CHECK (Quantidade > 0),
    CONSTRAINT ck_itens_compra_custo CHECK (Custo_Unit > 0),
    CONSTRAINT fk_itens_compra_compra_fornecedor FOREIGN KEY (ID_Compra,ID_Fornecedor)
        REFERENCES compras(ID_Compra,ID_Fornecedor),
    CONSTRAINT fk_itens_compra_produto_fornecedor FOREIGN KEY (ID_Produto,ID_Fornecedor)
        REFERENCES produto_fornecedor(ID_Produto,ID_Fornecedor)
) ENGINE=InnoDB;

CREATE TABLE estoque (
    ID_Loja INT NOT NULL,
    ID_Produto INT NOT NULL,
    Quantidade INT NOT NULL DEFAULT 0,
    Estoque_Minimo INT NOT NULL DEFAULT 0,
    PRIMARY KEY (ID_Loja, ID_Produto),
    CONSTRAINT ck_estoque_qtd CHECK (Quantidade >= 0),
    CONSTRAINT ck_estoque_minimo CHECK (Estoque_Minimo >= 0),
    CONSTRAINT fk_estoque_loja FOREIGN KEY (ID_Loja) REFERENCES lojas(ID_Loja),
    CONSTRAINT fk_estoque_produto FOREIGN KEY (ID_Produto) REFERENCES produtos(ID_Produto)
) ENGINE=InnoDB;

INSERT INTO estoque (ID_Loja,ID_Produto,Quantidade,Estoque_Minimo)
SELECT l.ID_Loja,p.ID_Produto,20+MOD(l.ID_Loja*p.ID_Produto,81),10+MOD(p.ID_Produto,11)
FROM lojas l CROSS JOIN produtos p;

CREATE TABLE historico_status_pedido (
    ID_Historico INT NOT NULL AUTO_INCREMENT,
    ID_Pedido INT NOT NULL,
    ID_Status TINYINT NOT NULL,
    Data_Status DATETIME NOT NULL,
    Observacao VARCHAR(255) NULL,
    PRIMARY KEY (ID_Historico),
    KEY idx_hist_status_pedido (ID_Pedido,Data_Status),
    CONSTRAINT fk_hist_status_pedido FOREIGN KEY (ID_Pedido) REFERENCES pedidos(ID_Pedido),
    CONSTRAINT fk_hist_status_status FOREIGN KEY (ID_Status) REFERENCES status_pedido(ID_Status)
) ENGINE=InnoDB;

-- Não fabricar uma cronologia operacional para registros LEGADO_V2.
INSERT INTO historico_status_pedido (ID_Pedido,ID_Status,Data_Status,Observacao)
SELECT ID_Pedido,ID_Status,Data_Pedido,'Estado inicial documentado do pedido sintético'
FROM pedidos
WHERE Origem_Registro='OPERACAO_V3';

CREATE TABLE movimentacoes_estoque (
    ID_Movimentacao BIGINT NOT NULL AUTO_INCREMENT,
    ID_Loja INT NOT NULL,
    ID_Produto INT NOT NULL,
    Tipo_Movimentacao VARCHAR(20) NOT NULL,
    Quantidade INT NOT NULL,
    Data_Movimentacao DATETIME NOT NULL,
    ID_Pedido INT NULL,
    ID_Compra INT NULL,
    Observacao VARCHAR(255) NULL,
    PRIMARY KEY (ID_Movimentacao),
    KEY idx_mov_estoque_produto_loja (ID_Produto,ID_Loja),
    KEY idx_mov_estoque_data (Data_Movimentacao),
    CONSTRAINT ck_mov_estoque_tipo CHECK (Tipo_Movimentacao IN ('ENTRADA','SAIDA','AJUSTE')),
    CONSTRAINT ck_mov_estoque_qtd CHECK (Quantidade > 0),
    CONSTRAINT ck_mov_estoque_origem CHECK (
        (Tipo_Movimentacao='AJUSTE' AND ID_Pedido IS NULL AND ID_Compra IS NULL) OR
        (Tipo_Movimentacao='ENTRADA' AND ID_Pedido IS NULL AND ID_Compra IS NOT NULL) OR
        (Tipo_Movimentacao='SAIDA' AND ID_Pedido IS NOT NULL AND ID_Compra IS NULL)
    ),
    CONSTRAINT fk_mov_estoque_saldo FOREIGN KEY (ID_Loja,ID_Produto) REFERENCES estoque(ID_Loja,ID_Produto),
    CONSTRAINT fk_mov_estoque_pedido FOREIGN KEY (ID_Pedido) REFERENCES pedidos(ID_Pedido),
    CONSTRAINT fk_mov_estoque_compra FOREIGN KEY (ID_Compra) REFERENCES compras(ID_Compra)
) ENGINE=InnoDB;

-- O saldo inicial é registrado como ajuste rastreável (independente do legado v2).
INSERT INTO movimentacoes_estoque (ID_Loja,ID_Produto,Tipo_Movimentacao,Quantidade,Data_Movimentacao,Observacao)
SELECT ID_Loja,ID_Produto,'AJUSTE',Quantidade,'2020-01-01 08:00:00','Saldo inicial da v4'
FROM estoque WHERE Quantidade>0;

INSERT INTO compras (ID_Compra,Data_Compra,ID_Fornecedor,ID_Loja,ID_Status_Compra,Valor_Total) VALUES
(1,'2020-01-01 09:03:00',1,4,2,13521.76),
(2,'2020-01-02 09:06:00',2,7,2,8653.30),
(3,'2020-01-03 09:09:00',3,2,2,10257.00),
(4,'2020-01-04 09:12:00',4,5,2,15648.45),
(5,'2020-01-05 09:15:00',5,8,2,17586.20),
(6,'2020-01-06 09:18:00',6,3,2,11147.76),
(7,'2020-01-07 09:21:00',7,6,2,23753.60),
(8,'2020-01-08 09:24:00',8,1,2,4186.92),
(9,'2020-01-09 09:27:00',9,4,2,6171.48),
(10,'2020-01-10 09:30:00',10,7,2,5613.94),
(11,'2020-01-11 09:33:00',11,2,2,4120.40),
(12,'2020-01-12 09:36:00',12,5,2,10584.18),
(13,'2020-01-13 09:39:00',13,8,2,7987.56),
(14,'2020-01-14 09:42:00',14,3,2,13082.16),
(15,'2020-01-15 09:45:00',15,6,2,14230.50),
(16,'2020-01-16 09:48:00',1,1,2,25861.20);
INSERT INTO itens_compra (ID_Compra,ID_Produto,ID_Fornecedor,Quantidade,Custo_Unit) VALUES
(1,1,1,6,927.36),
(1,16,1,7,1136.80),
(2,2,2,7,960.40),
(2,12,2,9,214.50),
(3,3,3,8,90.00),
(3,13,3,11,867.00),
(4,4,4,9,132.09),
(4,14,4,13,1112.28),
(5,5,5,10,100.46),
(5,15,5,15,1105.44),
(6,6,6,11,507.60),
(6,1,6,6,927.36),
(7,7,7,12,1339.20),
(7,2,7,8,960.40),
(8,8,8,13,252.84),
(8,3,8,10,90.00),
(9,9,9,14,327.60),
(9,4,9,12,132.09),
(10,10,10,15,280.50),
(10,5,10,14,100.46),
(11,11,11,5,316.48),
(11,6,11,5,507.60),
(12,12,12,6,201.63),
(12,7,12,7,1339.20),
(13,13,13,7,816.00),
(13,8,13,9,252.84),
(14,14,14,8,1184.82),
(14,9,14,11,327.60),
(15,15,15,9,1176.00),
(15,10,15,13,280.50),
(16,1,1,10,985.32),
(16,16,1,15,1067.20);

-- Compras recebidas geram movimento e atualizam estoque.
INSERT INTO movimentacoes_estoque (
    ID_Loja,ID_Produto,Tipo_Movimentacao,Quantidade,Data_Movimentacao,ID_Compra,Observacao
)
SELECT c.ID_Loja,ic.ID_Produto,'ENTRADA',ic.Quantidade,c.Data_Compra,c.ID_Compra,'Recebimento de compra'
FROM compras c JOIN itens_compra ic ON ic.ID_Compra=c.ID_Compra
WHERE c.ID_Status_Compra=2;

UPDATE estoque e
JOIN (
    SELECT c.ID_Loja,ic.ID_Produto,SUM(ic.Quantidade) AS Qtd_Entrada
    FROM compras c JOIN itens_compra ic ON ic.ID_Compra=c.ID_Compra
    WHERE c.ID_Status_Compra=2 GROUP BY c.ID_Loja,ic.ID_Produto
) x ON x.ID_Loja=e.ID_Loja AND x.ID_Produto=e.ID_Produto
SET e.Quantidade=e.Quantidade+x.Qtd_Entrada;

-- Somente as vendas sintéticas v3 são usadas na simulação de saídas de estoque.
-- Registros LEGADO_V2 antecedem o controle de estoque e não são reconstituídos como movimentação real.
INSERT INTO movimentacoes_estoque (
    ID_Loja,ID_Produto,Tipo_Movimentacao,Quantidade,Data_Movimentacao,ID_Pedido,Observacao
)
SELECT p.ID_Loja,ip.ID_Produto,'SAIDA',ip.Quantidade,p.Data_Pedido,p.ID_Pedido,'Saída por venda sintética'
FROM pedidos p JOIN itens_pedido ip ON ip.ID_Pedido=p.ID_Pedido
WHERE p.Origem_Registro='OPERACAO_V3';

-- Só registrar saídas efetivas quando houver saldo; não usar GREATEST para mascarar rupturas.
UPDATE estoque e
JOIN (
    SELECT p.ID_Loja,ip.ID_Produto,SUM(ip.Quantidade) AS Qtd_Saida
    FROM pedidos p JOIN itens_pedido ip ON ip.ID_Pedido=p.ID_Pedido
    WHERE p.Origem_Registro='OPERACAO_V3'
    GROUP BY p.ID_Loja,ip.ID_Produto
) x ON x.ID_Loja=e.ID_Loja AND x.ID_Produto=e.ID_Produto
SET e.Quantidade=e.Quantidade-x.Qtd_Saida;

-- A conciliação das compras foi preservada conforme fonte; diferenças do Valor_Total
-- em relação aos itens_compra devem ser auditadas, não reescritas silenciosamente.


-- Evolução v4 -> v5: aumento de volume para EXPLAIN e índices.
-- Executar somente em novo banco_v5 já criado a partir de banco_v4.
-- Os pedidos gerados para performance são dados sintéticos, não lançamentos de estoque.
USE banco_v5;

-- MySQL nao permite reabrir a mesma tabela TEMPORARY com varios aliases.
-- CTE de digitos reutilizavel, compatível com MySQL 8.4.
CREATE TEMPORARY TABLE tmp_seq AS
WITH digits AS (
    SELECT 0 AS n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3
    UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6
    UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9
)
SELECT 1 + a.n + 10*b.n + 100*c.n + 1000*d.n + 10000*e.n AS n
FROM digits a CROSS JOIN digits b CROSS JOIN digits c
CROSS JOIN digits d CROSS JOIN digits e
WHERE 1 + a.n + 10*b.n + 100*c.n + 1000*d.n + 10000*e.n <= 100000;
ALTER TABLE tmp_seq ADD PRIMARY KEY (n);

-- Completa cadastros até 10.000 clientes; IDs originais não são alterados.
INSERT INTO clientes (
    ID_Cliente,Nome,Sobrenome,Data_Nascimento,Estado_Civil,Sexo,Email,Telefone,Renda_Anual,Qtd_Filhos,Escolaridade
)
SELECT s.n,
       CONCAT('ClientePerf',LPAD(s.n,5,'0')),
       CONCAT('Sobrenome',LPAD(MOD(s.n,251),3,'0')),
       DATE_ADD('1975-01-01',INTERVAL MOD(s.n*29,12000) DAY),
       IF(MOD(s.n,3)=0,'C','S'), IF(MOD(s.n,2)=0,'F','M'),
       CONCAT('perf',LPAD(s.n,5,'0'),'@lab.local'),
       CONCAT('(86) 9',LPAD(MOD(s.n*7919,100000000),8,'0')),
       25000+MOD(s.n*193,180000), MOD(s.n,6),
       CASE MOD(s.n,4) WHEN 0 THEN 'Ensino Médio' WHEN 1 THEN 'Superior'
             WHEN 2 THEN 'Pós-graduado' ELSE 'Tecnólogo' END
FROM tmp_seq s
WHERE s.n<=10000 AND NOT EXISTS (
    SELECT 1 FROM clientes c WHERE c.ID_Cliente=s.n
);

-- Completa catálogo até 500 produtos, mantendo os IDs originais.
INSERT INTO produtos (
    ID_Produto,Nome_Produto,ID_Categoria,Marca_Produto,Num_Serie,Preco_Unit,Custo_Unit
)
SELECT s.n,
       CONCAT('Produto Performance ',LPAD(s.n,4,'0')),
       1+MOD(s.n-1,7),
       CASE MOD(s.n,8) WHEN 0 THEN 'DELL' WHEN 1 THEN 'SAMSUNG'
            WHEN 2 THEN 'LOGITECH' WHEN 3 THEN 'JBL' WHEN 4 THEN 'SONY'
            WHEN 5 THEN 'AKG' WHEN 6 THEN 'BLUE' ELSE 'LABTECH' END,
       CONCAT('PERF-',LPAD(s.n,7,'0')),
       100+MOD(s.n*181,6900),
       ROUND((100+MOD(s.n*181,6900))*(0.35+MOD(s.n,20)/100),2)
FROM tmp_seq s
WHERE s.n<=500 AND NOT EXISTS (
    SELECT 1 FROM produtos pr WHERE pr.ID_Produto=s.n
);

-- Cadastra dois fornecedores determinísticos por produto novo.
INSERT INTO produto_fornecedor (ID_Produto,ID_Fornecedor,Preco_Compra,Fornecedor_Principal,Prazo_Dias)
SELECT p.ID_Produto,1+MOD(p.ID_Produto-1,15),ROUND(p.Custo_Unit*0.95,2),TRUE,5+MOD(p.ID_Produto,8)
FROM produtos p
WHERE NOT EXISTS (
    SELECT 1 FROM produto_fornecedor pf
    WHERE pf.ID_Produto=p.ID_Produto AND pf.ID_Fornecedor=1+MOD(p.ID_Produto-1,15)
);
INSERT INTO produto_fornecedor (ID_Produto,ID_Fornecedor,Preco_Compra,Fornecedor_Principal,Prazo_Dias)
SELECT p.ID_Produto,1+MOD(p.ID_Produto+4,15),ROUND(p.Custo_Unit*1.03,2),FALSE,7+MOD(p.ID_Produto,10)
FROM produtos p
WHERE NOT EXISTS (
    SELECT 1 FROM produto_fornecedor pf
    WHERE pf.ID_Produto=p.ID_Produto AND pf.ID_Fornecedor=1+MOD(p.ID_Produto+4,15)
);

-- Novos saldos terão movimentação de AJUSTE rastreável.
INSERT INTO estoque (ID_Loja,ID_Produto,Quantidade,Estoque_Minimo)
SELECT l.ID_Loja,p.ID_Produto,
       20+MOD(l.ID_Loja*p.ID_Produto,81),10+MOD(p.ID_Produto,11)
FROM lojas l CROSS JOIN produtos p
WHERE NOT EXISTS (
    SELECT 1 FROM estoque e WHERE e.ID_Loja=l.ID_Loja AND e.ID_Produto=p.ID_Produto
);
INSERT INTO movimentacoes_estoque (ID_Loja,ID_Produto,Tipo_Movimentacao,Quantidade,Data_Movimentacao,Observacao)
SELECT e.ID_Loja,e.ID_Produto,'AJUSTE',e.Quantidade,'2022-01-01 07:00:00','Saldo inicial dos novos produtos de performance'
FROM estoque e
WHERE e.ID_Produto>16 AND NOT EXISTS (
    SELECT 1 FROM movimentacoes_estoque m
    WHERE m.ID_Loja=e.ID_Loja AND m.ID_Produto=e.ID_Produto
);

-- Pedidos sintéticos: nenhum registro LEGADO_V2 recebe vendedor ou pagamento fictício.
INSERT INTO pedidos (
    ID_Pedido,Data_Pedido,ID_Loja,ID_Cliente,ID_Vendedor,ID_Status,
    Valor_Total,Custo_Total,Origem_Registro,Observacao
)
SELECT s.n,
       DATE_ADD('2022-01-01 08:00:00', INTERVAL MOD(s.n*17,1460*24*60) MINUTE),
       1+MOD(s.n*3,8),
       1+MOD(s.n*31,10000),
       v.ID_Vendedor,
       CASE WHEN MOD(s.n,25)=0 THEN 3 WHEN MOD(s.n,7)=0 THEN 2 ELSE 4 END,
       0,0,'OPERACAO_V3','Carga de performance v5'
FROM tmp_seq s
JOIN (
    SELECT ID_Loja,MIN(ID_Vendedor) AS ID_Vendedor
    FROM vendedores GROUP BY ID_Loja
) v ON v.ID_Loja=1+MOD(s.n*3,8)
WHERE s.n>390 AND NOT EXISTS (
    SELECT 1 FROM pedidos p WHERE p.ID_Pedido=s.n
);

-- De 1 a 4 produtos diferentes por pedido.
INSERT INTO itens_pedido (
    ID_Pedido,ID_Produto,Quantidade,Preco_Unit,Custo_Unit,Desconto_Valor,Ajuste_Valor
)
SELECT p.ID_Pedido,pr.ID_Produto,
       1+MOD(p.ID_Pedido+pos.pos,5),
       pr.Preco_Unit,pr.Custo_Unit,
       CASE WHEN MOD(p.ID_Pedido+pos.pos,20)=0
            THEN ROUND(pr.Preco_Unit*0.05,2) ELSE 0 END,
       0
FROM pedidos p
JOIN (SELECT 1 AS pos UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4) pos
     ON pos.pos <= 1+MOD(p.ID_Pedido,4)
JOIN produtos pr ON pr.ID_Produto=1+MOD(p.ID_Pedido*17+pos.pos*29,500)
WHERE p.Origem_Registro='OPERACAO_V3' AND p.Observacao='Carga de performance v5'
  AND NOT EXISTS (
    SELECT 1 FROM itens_pedido ip
    WHERE ip.ID_Pedido=p.ID_Pedido AND ip.ID_Produto=pr.ID_Produto
);

UPDATE pedidos p
JOIN (
    SELECT ID_Pedido,
           SUM(Quantidade*Preco_Unit-Desconto_Valor+Ajuste_Valor) AS Total,
           SUM(Quantidade*Custo_Unit) AS Custo
    FROM itens_pedido GROUP BY ID_Pedido
) x ON x.ID_Pedido=p.ID_Pedido
SET p.Valor_Total=x.Total,p.Custo_Total=x.Custo
WHERE p.Origem_Registro='OPERACAO_V3' AND p.Observacao='Carga de performance v5';

-- Pagamentos apenas de pedidos SINTÉTICOS criados pela carga v5.
INSERT INTO pagamentos (ID_Pedido,ID_Forma,ID_Status,Valor_Pagamento,Data_Pagamento,Observacao)
SELECT p.ID_Pedido,1+MOD(p.ID_Pedido-1,5),
       CASE WHEN p.ID_Status=3 THEN 3 ELSE 2 END,
       p.Valor_Total,
       CASE WHEN p.ID_Status=3 THEN NULL ELSE DATE_ADD(p.Data_Pedido,INTERVAL 5 MINUTE) END,
       'Pagamento sintético de performance v5'
FROM pedidos p
WHERE p.Origem_Registro='OPERACAO_V3'
  AND p.Observacao='Carga de performance v5'
  AND NOT EXISTS (SELECT 1 FROM pagamentos pg WHERE pg.ID_Pedido=p.ID_Pedido);

INSERT INTO historico_status_pedido (ID_Pedido,ID_Status,Data_Status,Observacao)
SELECT p.ID_Pedido,p.ID_Status,p.Data_Pedido,'Estado inicial da carga sintética v5'
FROM pedidos p
WHERE p.Origem_Registro='OPERACAO_V3'
  AND p.Observacao='Carga de performance v5'
  AND NOT EXISTS (
    SELECT 1 FROM historico_status_pedido h WHERE h.ID_Pedido=p.ID_Pedido
);

DROP TEMPORARY TABLE tmp_seq;
-- digits CTE nao requer limpeza de tabela temporaria.
ANALYZE TABLE clientes,produtos,pedidos,itens_pedido,pagamentos,estoque;
